import './style.css';
const c=document.querySelector('#game'),g=c.getContext('2d');
const menu=document.querySelector('#menu'),over=document.querySelector('#gameover');
let w=0,h=0,dpr=1,run=false,last=0,score=0,ki=0,lane=1,jump=0,vy=0,slide=0,spawn=0,items=[],speed=1;
function resize(){dpr=Math.min(devicePixelRatio||1,2);w=innerWidth;h=innerHeight;c.width=w*dpr;c.height=h*dpr;c.style.width=w+'px';c.style.height=h+'px';g.setTransform(dpr,0,0,dpr,0,0)}
addEventListener('resize',resize);resize();
function polygon(a,col){g.fillStyle=col;g.beginPath();a.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();g.fill()}
function road(){
 let sky=g.createLinearGradient(0,0,0,h);sky.addColorStop(0,'#17285a');sky.addColorStop(.48,'#ed966f');sky.addColorStop(1,'#37244f');g.fillStyle=sky;g.fillRect(0,0,w,h);
 g.fillStyle='#ffe5a1';g.beginPath();g.arc(w*.78,h*.2,Math.min(w,h)*.07,0,7);g.fill();
 // distant floating cliffs
 for(let i=0;i<5;i++){let x=i*w/4;polygon([[x-55,h*.38],[x-20,h*.29],[x+10,h*.35],[x+60,h*.31],[x+95,h*.4],[x+75,h*.46],[x-50,h*.45]],'#59658a')}
 let hy=h*.34;polygon([[w*.39,hy],[w*.61,hy],[w*1.08,h],[w*-.08,h]],'#242b49');
 polygon([[w*.48,hy],[w*.52,hy],[w*.72,h],[w*.28,h]],'#333e60');
 for(let i=0;i<8;i++){let t=((i/8+(score*.0015)%1)%1),y=hy+(h-hy)*t*t,half=w*(.12+.52*t);g.strokeStyle='#b9a9a0';g.lineWidth=1+t*4;g.beginPath();g.moveTo(w/2-half,y);g.lineTo(w/2+half,y);g.stroke()}
}
function lx(l,z=1){return w/2+(l-1)*w*.19*(.25+.75*z)}
function fighter(x,y,s){
 g.save();g.translate(x,y);g.scale(s,s);
 g.fillStyle='#090d2388';g.beginPath();g.ellipse(0,8,27,8,0,0,7);g.fill();
 polygon([[-18,-26],[-4,-26],[-8,4],[-23,4]],'#263b70');polygon([[4,-26],[18,-26],[24,4],[9,4]],'#263b70');
 polygon([[-22,-63],[22,-63],[25,-22],[0,-13],[-25,-22]],'#ed762e');g.fillStyle='#236bc1';g.fillRect(-22,-39,44,6);
 polygon([[-21,-58],[-33,-48],[-27,-29],[-17,-34]],'#efb487');polygon([[21,-58],[33,-48],[27,-29],[17,-34]],'#efb487');
 g.fillStyle='#eeb78d';g.fillRect(-7,-77,14,14);g.beginPath();g.ellipse(0,-88,17,19,0,0,7);g.fill();
 polygon([[-17,-94],[-28,-113],[-11,-106],[-7,-127],[3,-106],[17,-121],[14,-101],[28,-108],[16,-86]],'#20202b');
 g.fillStyle='#fff';g.fillRect(-9,-91,5,3);g.fillRect(5,-91,5,3);g.restore()
}
function drawItem(o){let z=o.z,x=lx(o.lane,z),y=h*.34+(h*.65)*z,s=.25+z*.85;if(o.kind==='orb'){g.shadowColor='#54eaff';g.shadowBlur=20*s;g.fillStyle='#57eaff';g.beginPath();g.arc(x,y-25*s,10*s,0,7);g.fill();g.shadowBlur=0}else{g.fillStyle='#a84740';g.beginPath();g.roundRect(x-20*s,y-38*s,40*s,38*s,6*s);g.fill();g.fillStyle='#ffbd5a';g.fillRect(x-13*s,y-31*s,26*s,5*s)}}
function finish(){run=false;document.querySelector('#result').textContent='Score '+Math.floor(score)+' · Ki '+ki;over.classList.remove('hidden')}
function tick(t){let dt=Math.min((t-last)/16.67||1,2);last=t;road();
 if(run){score+=dt*speed;spawn-=dt;if(spawn<=0){items.push({lane:Math.floor(Math.random()*3),z:0,kind:Math.random()<.6?'orb':'block'});spawn=40+Math.random()*30;speed=Math.min(1.8,1+score/15000)}
 for(const o of items){o.z+=.009*speed*dt;drawItem(o);if(o.z>.88&&o.z<1.02&&o.lane===lane){if(o.kind==='orb'){ki++;o.z=2}else if(jump<12&&slide<=0){finish();break}}}
 items=items.filter(o=>o.z<1.1);vy-=.8*dt;jump=Math.max(0,jump+vy*dt);if(!jump)vy=0;slide=Math.max(0,slide-dt);
 fighter(lx(lane),h*.82-jump,Math.min(w/390,1.15)*(slide>0?.8:1));
 document.querySelector('#score').textContent='SCORE '+Math.floor(score);document.querySelector('#ki').textContent='KI '+ki;
 }else fighter(w/2,h*.82,Math.min(w/390,1.15));
 requestAnimationFrame(tick)}
function start(){score=0;ki=0;lane=1;jump=0;vy=0;slide=0;items=[];spawn=15;speed=1;run=true;menu.classList.add('hidden');over.classList.add('hidden')}
document.querySelector('#play').onclick=start;document.querySelector('#again').onclick=start;
let sx=0,sy=0;c.addEventListener('touchstart',e=>{sx=e.changedTouches[0].clientX;sy=e.changedTouches[0].clientY},{passive:true});
c.addEventListener('touchend',e=>{if(!run)return;let dx=e.changedTouches[0].clientX-sx,dy=e.changedTouches[0].clientY-sy;if(Math.abs(dx)>Math.abs(dy)&&Math.abs(dx)>25)lane=Math.max(0,Math.min(2,lane+(dx>0?1:-1)));else if(Math.abs(dy)>25){if(dy<0&&jump===0)vy=13;else if(dy>0)slide=22}},{passive:true});
c.addEventListener('click',()=>{if(run&&jump===0)vy=13});
addEventListener('keydown',e=>{if(!run)return;if(e.key==='ArrowLeft')lane=Math.max(0,lane-1);if(e.key==='ArrowRight')lane=Math.min(2,lane+1);if(e.key==='ArrowUp'&&jump===0)vy=13;if(e.key==='ArrowDown')slide=22});
requestAnimationFrame(tick);
