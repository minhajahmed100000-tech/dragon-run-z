# Dragon Run Z
Mobile-first anime-inspired endless runner prototype. Built with HTML Canvas, Vite and Capacitor.

## Local build
npm install
npm run build
npx cap add android
npx cap sync android
