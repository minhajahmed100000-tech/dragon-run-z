DRAGON RUN Z - BUILD AN ANDROID APK USING YOUR PHONE

1. Create a NEW GitHub repository named dragon-run-z. Set it to PRIVATE or PUBLIC.
2. Upload the CONTENTS of this ZIP (not the ZIP itself) to the repository root. Make sure the .github folder is included.
3. Open the repository's Actions tab. If GitHub asks, enable Actions.
4. Select "Build Dragon Run Z Android APK" from the workflows list.
5. Tap "Run workflow" and confirm.
6. Wait for the workflow to finish successfully (green check).
7. Open that completed run, scroll to Artifacts, and download "Dragon-Run-Z-debug-apk".
8. Extract the downloaded artifact ZIP and install app-debug.apk. Android may ask you to allow your browser/files app to install unknown apps.

NOTES
- This workflow creates a DEBUG APK for testing and personal installation, not a Play Store release.
- The workflow installs Capacitor 7 and generates the Android project in the cloud each run.
- Do not upload signing keys or passwords to this repository.
