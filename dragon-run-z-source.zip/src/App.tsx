import { useCallback, useEffect, useRef, useState } from "react";
import { Game, Hud, Result } from "./game/engine";
import { CHARACTERS } from "./game/sprites";
import CharacterPreview from "./components/CharacterPreview";

type Screen = "menu" | "playing" | "over";

const EMPTY_HUD: Hud = { score: 0, distance: 0, coins: 0, balls: 0, shield: 0, ss: 0, zone: "SNAKE WAY" };

const loadBest = () => {
  try {
    return Number(localStorage.getItem("dbz-run-best") || 0);
  } catch {
    return 0;
  }
};

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="h-2 w-16 overflow-hidden rounded bg-white/10">
        <div className="h-full rounded bg-gradient-to-r from-orange-400 to-yellow-300" style={{ width: `${value * 20}%` }} />
      </div>
      <span className="w-12 text-[10px] font-semibold tracking-widest text-white/60">{label}</span>
    </div>
  );
}

function DragonBallIcon({ n, lit }: { n: number; lit: boolean }) {
  return (
    <div
      className="relative flex h-6 w-6 items-center justify-center rounded-full border text-[9px] font-black text-red-700 transition-all sm:h-7 sm:w-7 sm:text-[10px]"
      style={{
        background: lit
          ? "radial-gradient(circle at 35% 30%, #fff3a8, #ffb52e 45%, #e2630c)"
          : "radial-gradient(circle at 35% 30%, #4a4458, #2a2536)",
        borderColor: lit ? "#a63c00" : "#444",
        boxShadow: lit ? "0 0 12px rgba(255,170,40,.9)" : "none",
        color: lit ? "#b30f14" : "#666",
        opacity: lit ? 1 : 0.65,
      }}
    >
      ★{n}
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [screen, setScreen] = useState<Screen>("menu");
  const screenRef = useRef<Screen>("menu");
  const [selected, setSelected] = useState(0);
  const [hud, setHud] = useState<Hud>(EMPTY_HUD);
  const [result, setResult] = useState<Result | null>(null);
  const [best, setBest] = useState(loadBest);
  const [newBest, setNewBest] = useState(false);
  const [paused, setPaused] = useState(false);
  const [muted, setMuted] = useState(false);
  const bestRef = useRef(best);

  const go = (s: Screen) => {
    screenRef.current = s;
    setScreen(s);
  };

  useEffect(() => {
    const game = new Game(canvasRef.current!, {
      onHud: (h) => setHud(h),
      onOver: (r) => {
        setResult(r);
        if (r.score > bestRef.current) {
          bestRef.current = r.score;
          setBest(r.score);
          setNewBest(true);
          try {
            localStorage.setItem("dbz-run-best", String(r.score));
          } catch {
            /* ignore */
          }
        } else {
          setNewBest(false);
        }
        screenRef.current = "over";
        setScreen("over");
      },
    });
    gameRef.current = game;
    return () => {
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  const start = useCallback(
    (idx: number) => {
      setHud({ ...EMPTY_HUD, shield: CHARACTERS[idx].startShield });
      setPaused(false);
      setNewBest(false);
      gameRef.current?.start(CHARACTERS[idx]);
      go("playing");
    },
    [],
  );

  const togglePause = useCallback(() => {
    if (screenRef.current !== "playing") return;
    setPaused((p) => {
      gameRef.current?.setPaused(!p);
      return !p;
    });
  }, []);

  const toMenu = () => {
    gameRef.current?.toMenu();
    go("menu");
  };

  // keyboard shortcuts for menus
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const s = screenRef.current;
      if (e.key === "p" || e.key === "P" || e.key === "Escape") {
        togglePause();
      } else if (e.key === "Enter") {
        if (s === "menu" || s === "over") start(selected);
      } else if (s === "menu") {
        if (e.key === "ArrowLeft") setSelected((v) => (v + CHARACTERS.length - 1) % CHARACTERS.length);
        if (e.key === "ArrowRight") setSelected((v) => (v + 1) % CHARACTERS.length);
      }
    };
    const onBlur = () => {
      if (screenRef.current === "playing") {
        gameRef.current?.setPaused(true);
        setPaused(true);
      }
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("blur", onBlur);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("blur", onBlur);
    };
  }, [selected, start, togglePause]);

  useEffect(() => {
    gameRef.current?.setMuted(muted);
  }, [muted]);

  const ch = CHARACTERS[selected];

  return (
    <div className="relative h-[100dvh] w-full select-none overflow-hidden bg-black font-['Rajdhani',sans-serif] text-white" style={{ touchAction: "none" }}>
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      {/* ------------------------------------------------------------ HUD */}
      {screen === "playing" && (
        <div className="pointer-events-none absolute inset-x-0 top-0 p-3 sm:p-5">
          <div className="flex items-start justify-between gap-3">
            <div className="rounded-xl bg-black/40 px-3 py-2 backdrop-blur-sm">
              <div className="font-['Bangers'] text-3xl leading-none tracking-wider text-yellow-300 drop-shadow sm:text-4xl">
                {hud.score.toLocaleString()}
              </div>
              <div className="text-xs font-semibold tracking-widest text-white/70">{hud.distance} m</div>
            </div>

            <div className="flex flex-col items-center gap-1.5">
              <div className="flex gap-1 rounded-full bg-black/40 px-2 py-1 backdrop-blur-sm">
                {Array.from({ length: 7 }).map((_, i) => (
                  <DragonBallIcon key={i} n={i + 1} lit={i < hud.balls} />
                ))}
              </div>
              {hud.ss > 0 && (
                <div className="w-44 sm:w-60">
                  <div className="mb-0.5 text-center font-['Bangers'] text-sm tracking-widest text-yellow-200 drop-shadow">
                    {ch.formName}
                  </div>
                  <div className="h-2.5 overflow-hidden rounded-full border border-yellow-200/60 bg-black/50">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-yellow-500 via-yellow-200 to-white"
                      style={{ width: `${hud.ss * 100}%`, boxShadow: "0 0 12px rgba(255,230,100,.9)" }}
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="pointer-events-auto flex items-start gap-2">
              <div className="rounded-xl bg-black/40 px-3 py-2 text-right backdrop-blur-sm">
                <div className="flex items-center justify-end gap-1.5 text-xl font-bold text-yellow-300">
                  <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-yellow-400 text-[11px] font-black text-amber-800">Z</span>
                  {hud.coins}
                </div>
                <div className="mt-0.5 flex items-center justify-end gap-1 text-xs font-semibold text-emerald-300">
                  {Array.from({ length: Math.max(hud.shield, 0) }).map((_, i) => (
                    <span key={i} title="Senzu shield">🫘</span>
                  ))}
                  {hud.shield === 0 && <span className="text-white/40">no shield</span>}
                </div>
              </div>
              <div className="flex flex-col gap-1.5">
                <button onClick={togglePause} className="h-9 w-9 rounded-lg bg-black/50 text-lg backdrop-blur-sm hover:bg-black/70" aria-label="Pause">
                  ⏸
                </button>
                <button onClick={() => setMuted((m) => !m)} className="h-9 w-9 rounded-lg bg-black/50 text-lg backdrop-blur-sm hover:bg-black/70" aria-label="Mute">
                  {muted ? "🔇" : "🔊"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ----------------------------------------------------------- MENU */}
      {screen === "menu" && (
        <div className="absolute inset-0 flex flex-col items-center overflow-y-auto bg-gradient-to-b from-black/60 via-black/25 to-black/70 px-4 py-5">
          <div className="my-auto flex w-full max-w-4xl flex-col items-center gap-4 sm:gap-5">
            <div className="text-center">
              <div className="font-['Bangers'] text-5xl leading-none tracking-wider sm:text-7xl md:text-8xl" style={{
                background: "linear-gradient(180deg,#fff7b0 0%,#ffc21a 45%,#ff6a00 100%)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                color: "transparent",
                filter: "drop-shadow(0 4px 0 #7a1d00) drop-shadow(0 0 22px rgba(255,160,30,.7))",
              }}>
                DRAGON RUN Z
              </div>
              <div className="mt-1 text-sm font-semibold tracking-[0.3em] text-white/80 sm:text-base">
                SNAKE WAY ENDLESS RUNNER
              </div>
            </div>

            <div className="flex w-full justify-center gap-2 sm:gap-3">
              {CHARACTERS.map((c, i) => (
                <button
                  key={c.id}
                  onClick={() => setSelected(i)}
                  className="group relative flex flex-1 basis-0 flex-col items-center overflow-hidden rounded-2xl border-2 pb-2 backdrop-blur-md transition-all"
                  style={{
                    maxWidth: 150,
                    borderColor: i === selected ? c.accent : "rgba(255,255,255,0.15)",
                    background: i === selected ? `linear-gradient(180deg, ${c.accent}55, rgba(0,0,0,0.55))` : "rgba(0,0,0,0.45)",
                    transform: i === selected ? "translateY(-6px) scale(1.04)" : "none",
                    boxShadow: i === selected ? `0 10px 30px ${c.accent}66` : "none",
                  }}
                >
                  <div className="hidden sm:block">
                    <CharacterPreview character={c} powered={i === selected} width={120} height={140} />
                  </div>
                  <div className="sm:hidden">
                    <CharacterPreview character={c} powered={i === selected} width={64} height={84} />
                  </div>
                  <div className="font-['Bangers'] text-sm tracking-wider sm:text-xl" style={{ color: i === selected ? "#fff" : "#ccc" }}>
                    {c.name}
                  </div>
                </button>
              ))}
            </div>

            <div
              className="w-full max-w-xl rounded-2xl border border-white/15 bg-black/55 p-4 backdrop-blur-md"
              style={{ boxShadow: `0 0 30px ${ch.accent}33` }}
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="font-['Bangers'] text-2xl tracking-wider sm:text-3xl" style={{ color: ch.accent }}>
                    {ch.name}
                  </div>
                  <div className="text-sm text-white/70">{ch.title}</div>
                  <div className="mt-2 text-sm">
                    <span className="font-bold text-yellow-300">{ch.perkName}: </span>
                    <span className="text-white/90">{ch.perkDesc}</span>
                  </div>
                </div>
                <div className="flex shrink-0 flex-col gap-1">
                  <Stat label="SPEED" value={ch.stats.speed} />
                  <Stat label="POWER" value={ch.stats.power} />
                  <Stat label="KI" value={ch.stats.ki} />
                </div>
              </div>
            </div>

            <button
              onClick={() => start(selected)}
              className="rounded-full border-4 border-yellow-200 bg-gradient-to-b from-orange-400 to-red-600 px-12 py-3 font-['Bangers'] text-3xl tracking-widest text-white shadow-[0_6px_0_#7a1d00,0_0_30px_rgba(255,140,30,.7)] transition-transform hover:scale-105 active:translate-y-1 sm:text-4xl"
            >
              START RUN
            </button>

            <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-1 text-center text-xs text-white/75 sm:text-sm">
              <span><b className="text-yellow-300">← →</b> / swipe: change lane</span>
              <span><b className="text-yellow-300">↑ / Space</b>: jump (hurdle Saibamen &amp; gaps)</span>
              <span><b className="text-yellow-300">↓</b>: slide under Death Beams</span>
            </div>
            <div className="text-center text-xs text-white/60">
              Collect <b className="text-orange-300">7 Dragon Balls</b> to power up and smash through everything! · Best: <b className="text-yellow-300">{best.toLocaleString()}</b>
            </div>
            <div className="text-center text-[10px] text-white/35">Unofficial fan-made tribute. Dragon Ball Z © Akira Toriyama / Toei Animation.</div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------- PAUSED */}
      {screen === "playing" && paused && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-black/60 backdrop-blur-sm">
          <div className="font-['Bangers'] text-6xl tracking-widest text-yellow-300 drop-shadow-lg">PAUSED</div>
          <button
            onClick={togglePause}
            className="rounded-full border-4 border-yellow-200 bg-gradient-to-b from-orange-400 to-red-600 px-10 py-2 font-['Bangers'] text-3xl tracking-widest shadow-[0_5px_0_#7a1d00]"
          >
            RESUME
          </button>
          <button onClick={toMenu} className="text-sm font-semibold tracking-widest text-white/70 underline hover:text-white">
            QUIT TO MENU
          </button>
        </div>
      )}

      {/* ---------------------------------------------------- GAME OVER */}
      {screen === "over" && result && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-gradient-to-b from-black/40 to-black/80 px-4">
          <div className="font-['Bangers'] text-5xl tracking-widest text-red-400 drop-shadow-[0_0_20px_rgba(255,60,60,.8)] sm:text-7xl">
            {result.fell ? "LOST IN THE CLOUDS" : "DEFEATED!"}
          </div>
          <div className="w-full max-w-sm rounded-2xl border border-white/20 bg-black/60 p-5 text-center backdrop-blur-md">
            {newBest && <div className="mb-1 animate-pulse font-['Bangers'] text-2xl tracking-widest text-yellow-300">★ NEW BEST SCORE ★</div>}
            <div className="text-xs tracking-[0.3em] text-white/60">SCORE</div>
            <div className="font-['Bangers'] text-6xl text-yellow-300">{result.score.toLocaleString()}</div>
            <div className="mt-3 grid grid-cols-3 gap-2 text-sm">
              <div className="rounded-lg bg-white/10 p-2">
                <div className="text-[10px] tracking-widest text-white/60">DISTANCE</div>
                <div className="text-lg font-bold">{result.distance} m</div>
              </div>
              <div className="rounded-lg bg-white/10 p-2">
                <div className="text-[10px] tracking-widest text-white/60">ZENI</div>
                <div className="text-lg font-bold text-yellow-300">{result.coins}</div>
              </div>
              <div className="rounded-lg bg-white/10 p-2">
                <div className="text-[10px] tracking-widest text-white/60">BEST</div>
                <div className="text-lg font-bold">{best.toLocaleString()}</div>
              </div>
            </div>
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            <button
              onClick={() => start(selected)}
              className="rounded-full border-4 border-yellow-200 bg-gradient-to-b from-orange-400 to-red-600 px-8 py-2 font-['Bangers'] text-3xl tracking-widest shadow-[0_5px_0_#7a1d00] transition-transform hover:scale-105"
            >
              RUN AGAIN
            </button>
            <button
              onClick={toMenu}
              className="rounded-full border-4 border-white/40 bg-white/10 px-8 py-2 font-['Bangers'] text-3xl tracking-widest shadow-[0_5px_0_rgba(0,0,0,.5)] transition-transform hover:scale-105"
            >
              FIGHTERS
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
