import { useEffect, useRef } from "react";
import { CharacterDef, drawFighter } from "../game/sprites";

interface Props {
  character: CharacterDef;
  powered?: boolean;
  width?: number;
  height?: number;
}

export default function CharacterPreview({ character, powered = false, width = 120, height = 150 }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    let raf = 0;
    const start = performance.now();
    const loop = (now: number) => {
      const t = (now - start) / 1000;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, width, height);
      const h = height * 0.62;
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.beginPath();
      ctx.ellipse(width / 2, height * 0.86, h * 0.28, h * 0.07, 0, 0, Math.PI * 2);
      ctx.fill();
      drawFighter(ctx, character, width / 2, height * 0.86, h, t, "run", powered);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [character, powered, width, height]);

  return <canvas ref={ref} style={{ width, height }} />;
}
