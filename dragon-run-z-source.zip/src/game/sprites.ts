// All characters, enemies and pickups are drawn procedurally with canvas paths.
// Coordinates are in "unit space": 1 unit == the height of a character, y grows downward,
// feet at y = 0, so the body occupies roughly y = -1 .. 0.

export type Pose = "run" | "jump" | "slide";
export type HairType = "goku" | "vegeta" | "gohan" | "trunks" | "piccolo";

export interface CharacterDef {
  id: string;
  name: string;
  title: string;
  hair: HairType;
  skin: string;
  hairColor: string;
  pants: string;
  top: string;
  upperArm: string;
  wrist: string;
  hand: string;
  belt: string;
  boots: string;
  aura: string;
  auraCore: string;
  accent: string;
  formName: string;
  perkName: string;
  perkDesc: string;
  doubleJump: boolean;
  magnet: boolean;
  startShield: number;
  scoreMult: number;
  ssTime: number;
  stats: { speed: number; power: number; ki: number };
}

export const CHARACTERS: CharacterDef[] = [
  {
    id: "goku",
    name: "GOKU",
    title: "Saiyan raised on Earth",
    hair: "goku",
    skin: "#f4c79b",
    hairColor: "#16151f",
    pants: "#f06a12",
    top: "#f57a16",
    upperArm: "#2150d6",
    wrist: "#2150d6",
    hand: "#f4c79b",
    belt: "#2150d6",
    boots: "#2150d6",
    aura: "255,214,64",
    auraCore: "255,250,200",
    accent: "#ff8a1f",
    formName: "SUPER SAIYAN",
    perkName: "Kaio-Ken Spirit",
    perkDesc: "Super Saiyan lasts 50% longer.",
    doubleJump: false,
    magnet: false,
    startShield: 0,
    scoreMult: 1,
    ssTime: 15,
    stats: { speed: 4, power: 5, ki: 5 },
  },
  {
    id: "vegeta",
    name: "VEGETA",
    title: "Prince of all Saiyans",
    hair: "vegeta",
    skin: "#f1c096",
    hairColor: "#1a1822",
    pants: "#2c4aa0",
    top: "#e9edf5",
    upperArm: "#2c4aa0",
    wrist: "#2c4aa0",
    hand: "#ffffff",
    belt: "#2c4aa0",
    boots: "#ffffff",
    aura: "255,230,90",
    auraCore: "255,255,215",
    accent: "#4a78ff",
    formName: "SUPER SAIYAN",
    perkName: "Saiyan Pride",
    perkDesc: "All score is multiplied by x1.5.",
    doubleJump: false,
    magnet: false,
    startShield: 0,
    scoreMult: 1.5,
    ssTime: 10,
    stats: { speed: 5, power: 5, ki: 4 },
  },
  {
    id: "gohan",
    name: "GOHAN",
    title: "Hidden potential",
    hair: "gohan",
    skin: "#f4c79b",
    hairColor: "#17161f",
    pants: "#6a2c8c",
    top: "#7a35a0",
    upperArm: "#7a35a0",
    wrist: "#2a46b8",
    hand: "#f4c79b",
    belt: "#c4251f",
    boots: "#2a46b8",
    aura: "255,220,80",
    auraCore: "255,250,210",
    accent: "#a64fe0",
    formName: "SUPER SAIYAN",
    perkName: "Hidden Power",
    perkDesc: "Starts every run with a Senzu shield.",
    doubleJump: false,
    magnet: false,
    startShield: 1,
    scoreMult: 1,
    ssTime: 10,
    stats: { speed: 3, power: 4, ki: 5 },
  },
  {
    id: "piccolo",
    name: "PICCOLO",
    title: "Namekian warrior",
    hair: "piccolo",
    skin: "#6fbf4a",
    hairColor: "#ffffff",
    pants: "#5b2d8a",
    top: "#6a34a0",
    upperArm: "#6a34a0",
    wrist: "#2a46b8",
    hand: "#6fbf4a",
    belt: "#2a46b8",
    boots: "#7a3fb0",
    aura: "190,255,170",
    auraCore: "240,255,230",
    accent: "#58c23c",
    formName: "NAMEKIAN FUSION",
    perkName: "Namekian Flight",
    perkDesc: "Can jump a second time in mid-air.",
    doubleJump: true,
    magnet: false,
    startShield: 0,
    scoreMult: 1,
    ssTime: 10,
    stats: { speed: 4, power: 4, ki: 4 },
  },
  {
    id: "trunks",
    name: "TRUNKS",
    title: "Warrior from the future",
    hair: "trunks",
    skin: "#f4c79b",
    hairColor: "#9a7fd8",
    pants: "#5a6482",
    top: "#3c62b8",
    upperArm: "#3c62b8",
    wrist: "#3c62b8",
    hand: "#f4c79b",
    belt: "#6b4a2a",
    boots: "#6b4a2a",
    aura: "255,224,100",
    auraCore: "255,252,215",
    accent: "#9a7fd8",
    formName: "SUPER SAIYAN",
    perkName: "Zeni Magnet",
    perkDesc: "Pulls nearby Zeni coins toward you.",
    doubleJump: false,
    magnet: true,
    startShield: 0,
    scoreMult: 1,
    ssTime: 10,
    stats: { speed: 5, power: 3, ki: 4 },
  },
];

/* ------------------------------------------------------------------ helpers */

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rad = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rad, y);
  ctx.arcTo(x + w, y, x + w, y + h, rad);
  ctx.arcTo(x + w, y + h, x, y + h, rad);
  ctx.arcTo(x, y + h, x, y, rad);
  ctx.arcTo(x, y, x + w, y, rad);
  ctx.closePath();
}

function ell(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number) {
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
}

function star(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    const rad = i % 2 === 0 ? r : r * 0.45;
    const px = x + Math.cos(a) * rad;
    const py = y + Math.sin(a) * rad;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

// Right half of a head-relative hair silhouette (top-centre -> nape). Mirrored when drawn.
const HAIR: Record<string, number[][]> = {
  goku: [[0, -0.36], [0.05, -0.22], [0.16, -0.35], [0.14, -0.19], [0.3, -0.25], [0.2, -0.08], [0.33, 0], [0.2, 0.05], [0.19, 0.12], [0.1, 0.16], [0, 0.16]],
  ss: [[0, -0.52], [0.06, -0.28], [0.2, -0.47], [0.17, -0.22], [0.34, -0.35], [0.22, -0.1], [0.37, -0.07], [0.21, 0.02], [0.2, 0.12], [0.1, 0.16], [0, 0.16]],
  vegeta: [[0, -0.46], [0.06, -0.29], [0.13, -0.45], [0.14, -0.25], [0.23, -0.34], [0.2, -0.1], [0.22, 0.02], [0.17, 0.12], [0.08, 0.16], [0, 0.16]],
  trunks: [[0, -0.23], [0.1, -0.25], [0.18, -0.19], [0.23, -0.06], [0.24, 0.1], [0.21, 0.22], [0.1, 0.23], [0, 0.2]],
};

function drawHair(ctx: CanvasRenderingContext2D, pts: number[][], color: string, sx: number, sy: number, highlight?: string) {
  const path = () => {
    ctx.beginPath();
    pts.forEach((p, i) => (i === 0 ? ctx.moveTo(p[0] * sx, p[1] * sy) : ctx.lineTo(p[0] * sx, p[1] * sy)));
    for (let i = pts.length - 1; i >= 0; i--) ctx.lineTo(-pts[i][0] * sx, pts[i][1] * sy);
    ctx.closePath();
  };
  path();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.strokeStyle = "rgba(0,0,0,0.55)";
  ctx.lineWidth = 0.012;
  ctx.lineJoin = "round";
  ctx.stroke();
  if (highlight) {
    ctx.save();
    ctx.translate(-0.02, -0.03);
    ctx.scale(0.62, 0.62);
    path();
    ctx.globalAlpha = 0.35;
    ctx.fillStyle = highlight;
    ctx.fill();
    ctx.restore();
  }
}

function drawAura(ctx: CanvasRenderingContext2D, c: CharacterDef, t: number) {
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  const g = ctx.createRadialGradient(0, -0.5, 0.05, 0, -0.5, 0.95);
  g.addColorStop(0, `rgba(${c.aura},0.55)`);
  g.addColorStop(1, `rgba(${c.aura},0)`);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(0, -0.5, 0.75, 1.0, 0, 0, Math.PI * 2);
  ctx.fill();
  // flame tongues
  for (let k = 0; k < 9; k++) {
    const x = (k - 4) * 0.095;
    const hgt = 0.75 + 0.35 * Math.sin(t * 17 + k * 1.9) + (4 - Math.abs(k - 4)) * 0.07;
    const w = 0.07 + 0.02 * Math.sin(t * 13 + k);
    ctx.beginPath();
    ctx.moveTo(x - w, 0.0);
    ctx.quadraticCurveTo(x - w * 1.4, -hgt * 0.5, x + Math.sin(t * 20 + k) * 0.05, -hgt);
    ctx.quadraticCurveTo(x + w * 1.4, -hgt * 0.5, x + w, 0.0);
    ctx.fillStyle = `rgba(${c.aura},0.42)`;
    ctx.fill();
  }
  // electric sparks
  const seed = Math.floor(t * 18);
  ctx.strokeStyle = `rgba(${c.auraCore},0.95)`;
  ctx.lineWidth = 0.014;
  for (let n = 0; n < 3; n++) {
    const h = (a: number) => {
      const s = Math.sin((seed + n * 13) * 12.9898 + a * 78.233) * 43758.5453;
      return s - Math.floor(s);
    };
    let x = (h(1) - 0.5) * 0.7;
    let y = -0.1 - h(2) * 0.9;
    ctx.beginPath();
    ctx.moveTo(x, y);
    for (let i = 0; i < 4; i++) {
      x += (h(3 + i) - 0.5) * 0.18;
      y -= 0.08 + h(7 + i) * 0.08;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  ctx.restore();
}

/* ---------------------------------------------------------------- fighters */

export function drawFighter(
  ctx: CanvasRenderingContext2D,
  c: CharacterDef,
  x: number,
  footY: number,
  h: number,
  t: number,
  pose: Pose,
  ss: boolean,
) {
  ctx.save();
  ctx.translate(x, footY);
  ctx.scale(h, h);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  if (ss) drawAura(ctx, c, t);

  if (pose === "slide") ctx.scale(1.15, 0.62);
  const phase = t * 13;
  const bob = pose === "run" ? Math.abs(Math.sin(phase)) * 0.035 : 0;
  ctx.translate(0, -bob);

  const isPic = c.hair === "piccolo";
  const skin = ss && isPic ? "#9ae872" : c.skin;
  const hairCol = ss && !isPic ? "#ffe23d" : c.hairColor;
  const outline = "rgba(0,0,0,0.5)";

  // legs
  for (const i of [-1, 1]) {
    const ph = pose === "run" ? Math.sin(phase + (i > 0 ? Math.PI : 0)) : 0;
    const lift = pose === "jump" ? (i > 0 ? 0.16 : 0.08) : Math.max(0, ph) * 0.15;
    const lx = i * 0.095;
    ctx.fillStyle = c.pants;
    rr(ctx, lx - 0.055, -0.43, 0.11, 0.43 - lift - 0.07, 0.04);
    ctx.fill();
    ctx.fillStyle = c.boots;
    rr(ctx, lx - 0.07, -lift - 0.11, 0.14, 0.11, 0.04);
    ctx.fill();
    ctx.strokeStyle = outline;
    ctx.lineWidth = 0.008;
    ctx.stroke();
    if (c.hair === "vegeta" || c.hair === "goku") {
      ctx.fillStyle = c.hair === "vegeta" ? "#f2c230" : "#f5f0ff";
      ctx.fillRect(lx - 0.07, -lift - 0.075, 0.14, 0.015);
    }
  }

  // arms (drawn behind torso)
  const drawArm = (side: number) => {
    const angle =
      pose === "run"
        ? Math.sin(phase + (side > 0 ? 0 : Math.PI)) * 0.55 - side * 0.14
        : pose === "jump"
          ? -side * (2.4 + Math.sin(t * 9) * 0.08)
          : -side * 0.5;
    ctx.save();
    ctx.translate(side * 0.2, -0.68);
    ctx.rotate(angle);
    ctx.fillStyle = c.upperArm;
    rr(ctx, -0.045, -0.02, 0.09, 0.2, 0.04);
    ctx.fill();
    ctx.fillStyle = c.wrist;
    rr(ctx, -0.048, 0.16, 0.096, 0.05, 0.02);
    ctx.fill();
    ctx.fillStyle = c.hand;
    ell(ctx, 0, 0.255, 0.05, 0.055);
    ctx.fill();
    ctx.strokeStyle = outline;
    ctx.lineWidth = 0.008;
    ctx.stroke();
    ctx.restore();
  };
  drawArm(-1);
  drawArm(1);

  // torso
  ctx.beginPath();
  ctx.moveTo(-0.2, -0.7);
  ctx.quadraticCurveTo(0, -0.76, 0.2, -0.7);
  ctx.lineTo(0.16, -0.4);
  ctx.lineTo(-0.16, -0.4);
  ctx.closePath();
  ctx.fillStyle = c.top;
  ctx.fill();
  ctx.strokeStyle = outline;
  ctx.lineWidth = 0.009;
  ctx.stroke();

  if (c.hair === "goku") {
    // Turtle School emblem
    ctx.fillStyle = "#ffffff";
    ell(ctx, 0, -0.56, 0.085, 0.085);
    ctx.fill();
    ctx.strokeStyle = "#c9570c";
    ctx.lineWidth = 0.012;
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-0.045, -0.56);
    ctx.lineTo(-0.022, -0.6);
    ctx.lineTo(0.022, -0.6);
    ctx.lineTo(0.045, -0.56);
    ctx.lineTo(0.022, -0.52);
    ctx.lineTo(-0.022, -0.52);
    ctx.closePath();
    ctx.stroke();
  }
  if (c.hair === "vegeta") {
    ctx.fillStyle = "#2c4aa0";
    rr(ctx, -0.07, -0.68, 0.14, 0.26, 0.03);
    ctx.fill();
    // shoulder guards
    ctx.fillStyle = "#f2c230";
    for (const s of [-1, 1]) {
      rr(ctx, s * 0.2 - 0.06, -0.73, 0.12, 0.09, 0.04);
      ctx.fill();
      ctx.strokeStyle = outline;
      ctx.lineWidth = 0.008;
      ctx.stroke();
    }
  }
  if (c.hair === "gohan") {
    ctx.fillStyle = "#e8e0ff";
    ctx.fillRect(-0.16, -0.62, 0.32, 0.025);
  }
  // belt / sash
  ctx.fillStyle = c.belt;
  rr(ctx, -0.17, -0.46, 0.34, 0.07, 0.025);
  ctx.fill();
  if (c.hair === "goku" || c.hair === "gohan" || c.hair === "piccolo") {
    ctx.fillRect(0.02, -0.4, 0.05, 0.12);
  }

  if (c.hair === "trunks") {
    // sword over the back
    ctx.save();
    ctx.translate(0.02, -0.55);
    ctx.rotate(-0.55);
    ctx.fillStyle = "#6b3f1f";
    rr(ctx, -0.035, -0.28, 0.07, 0.62, 0.025);
    ctx.fill();
    ctx.fillStyle = "#e0b43a";
    rr(ctx, -0.075, -0.3, 0.15, 0.05, 0.02);
    ctx.fill();
    ctx.fillStyle = "#2a2a2a";
    rr(ctx, -0.022, -0.43, 0.044, 0.14, 0.02);
    ctx.fill();
    ctx.restore();
    // jacket collar highlight
    ctx.fillStyle = "#e9c24a";
    ctx.fillRect(-0.04, -0.72, 0.08, 0.025);
  }

  if (isPic) {
    // white cape + shoulder pads
    const flap = Math.sin(t * 11) * 0.025;
    ctx.beginPath();
    ctx.moveTo(-0.3, -0.72);
    ctx.lineTo(0.3, -0.72);
    ctx.quadraticCurveTo(0.34 + flap, -0.4, 0.27, -0.12 + flap);
    ctx.lineTo(0.12, -0.17);
    ctx.lineTo(0, -0.1 + flap);
    ctx.lineTo(-0.12, -0.17);
    ctx.lineTo(-0.27, -0.12 - flap);
    ctx.quadraticCurveTo(-0.34 - flap, -0.4, -0.3, -0.72);
    ctx.closePath();
    ctx.fillStyle = "#f4f4f8";
    ctx.fill();
    ctx.strokeStyle = "rgba(60,60,90,0.6)";
    ctx.lineWidth = 0.01;
    ctx.stroke();
    ctx.fillStyle = "#e1e1ee";
    ctx.fillRect(-0.01, -0.7, 0.02, 0.55);
    ctx.fillStyle = "#ffffff";
    for (const s of [-1, 1]) {
      rr(ctx, s * 0.24 - 0.09, -0.77, 0.18, 0.1, 0.05);
      ctx.fill();
      ctx.strokeStyle = "rgba(60,60,90,0.6)";
      ctx.stroke();
    }
  }

  // neck + head
  ctx.fillStyle = skin;
  ctx.fillRect(-0.045, -0.76, 0.09, 0.07);
  const hy = -0.87;
  if (isPic) {
    // pointy ears
    ctx.fillStyle = skin;
    for (const s of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(s * 0.14, hy - 0.04);
      ctx.lineTo(s * 0.3, hy - 0.1);
      ctx.lineTo(s * 0.15, hy + 0.04);
      ctx.closePath();
      ctx.fill();
    }
  } else {
    ctx.fillStyle = skin;
    ell(ctx, -0.16, hy + 0.02, 0.03, 0.04);
    ctx.fill();
    ell(ctx, 0.16, hy + 0.02, 0.03, 0.04);
    ctx.fill();
  }
  ctx.fillStyle = skin;
  ell(ctx, 0, hy, 0.165, 0.17);
  ctx.fill();
  ctx.strokeStyle = outline;
  ctx.lineWidth = 0.009;
  ctx.stroke();

  ctx.save();
  ctx.translate(0, hy);
  if (isPic) {
    // white turban
    ctx.beginPath();
    ctx.ellipse(0, -0.045, 0.175, 0.13, 0, Math.PI, Math.PI * 2);
    ctx.lineTo(0.175, -0.02);
    ctx.lineTo(-0.175, -0.02);
    ctx.closePath();
    ctx.fillStyle = "#f6f6fb";
    ctx.fill();
    ctx.strokeStyle = "rgba(60,60,90,0.6)";
    ctx.stroke();
    ctx.fillStyle = "#6a34a0";
    ctx.fillRect(-0.175, -0.04, 0.35, 0.03);
    // antennae
    ctx.strokeStyle = skin;
    ctx.lineWidth = 0.028;
    for (const s of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(s * 0.07, -0.15);
      ctx.quadraticCurveTo(s * 0.12, -0.26, s * 0.1, -0.31);
      ctx.stroke();
    }
  } else if (c.hair === "goku") {
    drawHair(ctx, ss ? HAIR.ss : HAIR.goku, hairCol, 1, 1, ss ? "#fff8b0" : "#6f86d8");
  } else if (c.hair === "gohan") {
    drawHair(ctx, ss ? HAIR.ss : HAIR.goku, hairCol, 0.88, 0.88, ss ? "#fff8b0" : "#6f86d8");
  } else if (c.hair === "vegeta") {
    drawHair(ctx, HAIR.vegeta, hairCol, 1, ss ? 1.1 : 1, ss ? "#fff8b0" : "#6f86d8");
  } else if (c.hair === "trunks") {
    if (ss) drawHair(ctx, HAIR.ss, hairCol, 0.95, 0.95, "#fff8b0");
    else drawHair(ctx, HAIR.trunks, hairCol, 1, 1, "#d4c4ff");
  }
  ctx.restore();

  ctx.restore();
}

/* ------------------------------------------------------------------ enemies */

export type EnemyKind = "saibaman" | "frieza" | "celljr";

export function drawEnemy(ctx: CanvasRenderingContext2D, kind: EnemyKind, cx: number, footY: number, s: number, t: number) {
  ctx.save();
  ctx.translate(cx, footY);
  ctx.scale(s, s);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  const ol = "rgba(10,20,10,0.7)";

  if (kind === "saibaman") {
    const hop = Math.abs(Math.sin(t * 7)) * 0.06;
    ctx.translate(0, -hop);
    // legs
    ctx.fillStyle = "#4c8f3c";
    rr(ctx, -0.22, -0.28, 0.14, 0.28, 0.05);
    ctx.fill();
    rr(ctx, 0.08, -0.28, 0.14, 0.28, 0.05);
    ctx.fill();
    ctx.fillStyle = "#2f5e27";
    rr(ctx, -0.26, -0.05, 0.2, 0.06, 0.03);
    ctx.fill();
    rr(ctx, 0.06, -0.05, 0.2, 0.06, 0.03);
    ctx.fill();
    // body
    ctx.fillStyle = "#68a850";
    ell(ctx, 0, -0.42, 0.23, 0.21);
    ctx.fill();
    ctx.strokeStyle = ol;
    ctx.lineWidth = 0.014;
    ctx.stroke();
    ctx.fillStyle = "#a6d489";
    ell(ctx, 0, -0.38, 0.13, 0.12);
    ctx.fill();
    // arms
    const w = Math.sin(t * 8) * 0.05;
    ctx.strokeStyle = "#5a9a45";
    ctx.lineWidth = 0.1;
    for (const sd of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(sd * 0.2, -0.47);
      ctx.lineTo(sd * 0.4, -0.55 + w * sd);
      ctx.lineTo(sd * 0.36, -0.8 - w * sd);
      ctx.stroke();
      ctx.strokeStyle = "#f4f4e0";
      ctx.lineWidth = 0.022;
      for (const k of [-1, 0, 1]) {
        ctx.beginPath();
        ctx.moveTo(sd * 0.36 + k * 0.035, -0.82 - w * sd);
        ctx.lineTo(sd * 0.36 + k * 0.06, -0.9 - w * sd);
        ctx.stroke();
      }
      ctx.strokeStyle = "#5a9a45";
      ctx.lineWidth = 0.1;
    }
    // head
    ctx.fillStyle = "#7cbb5f";
    ell(ctx, 0, -0.73, 0.28, 0.26);
    ctx.fill();
    ctx.strokeStyle = ol;
    ctx.lineWidth = 0.014;
    ctx.stroke();
    ctx.strokeStyle = "#3d7a32";
    ctx.lineWidth = 0.028;
    for (let k = -2; k <= 2; k++) {
      ctx.beginPath();
      ctx.moveTo(k * 0.07, -0.98);
      ctx.quadraticCurveTo(k * 0.13, -0.88, k * 0.14, -0.79);
      ctx.stroke();
    }
    // eyes
    for (const sd of [-1, 1]) {
      ctx.fillStyle = "#fff3a0";
      ell(ctx, sd * 0.11, -0.7, 0.075, 0.08);
      ctx.fill();
      ctx.strokeStyle = ol;
      ctx.lineWidth = 0.012;
      ctx.stroke();
      ctx.fillStyle = "#d01c1c";
      ell(ctx, sd * 0.1, -0.69, 0.028, 0.04);
      ctx.fill();
      ctx.strokeStyle = "#1c3a16";
      ctx.lineWidth = 0.03;
      ctx.beginPath();
      ctx.moveTo(sd * 0.2, -0.82);
      ctx.lineTo(sd * 0.04, -0.75);
      ctx.stroke();
    }
    // mouth
    ctx.fillStyle = "#2a0f0f";
    ell(ctx, 0, -0.58, 0.12, 0.05);
    ctx.fill();
    ctx.fillStyle = "#ffffff";
    for (let k = -2; k <= 2; k++) {
      ctx.beginPath();
      ctx.moveTo(k * 0.04 - 0.017, -0.62);
      ctx.lineTo(k * 0.04, -0.56);
      ctx.lineTo(k * 0.04 + 0.017, -0.62);
      ctx.fill();
    }
  } else if (kind === "frieza") {
    const hov = Math.sin(t * 3) * 0.05;
    ctx.translate(0, -0.1 + hov);
    // menacing aura
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const g = ctx.createRadialGradient(0, -1.2, 0.1, 0, -1.2, 1.3);
    g.addColorStop(0, "rgba(190,90,255,0.4)");
    g.addColorStop(1, "rgba(190,90,255,0)");
    ctx.fillStyle = g;
    ctx.fillRect(-1.4, -2.6, 2.8, 2.8);
    ctx.restore();
    // tail
    ctx.strokeStyle = "#f2eef8";
    ctx.lineWidth = 0.09;
    ctx.beginPath();
    ctx.moveTo(0.1, -0.7);
    ctx.bezierCurveTo(0.7, -0.5, 0.8, -0.1, 0.55 + Math.sin(t * 4) * 0.08, 0.05);
    ctx.stroke();
    // legs
    ctx.fillStyle = "#f2eef8";
    rr(ctx, -0.3, -1.0, 0.25, 1.0, 0.1);
    ctx.fill();
    rr(ctx, 0.05, -1.0, 0.25, 1.0, 0.1);
    ctx.fill();
    ctx.strokeStyle = "rgba(60,30,90,0.55)";
    ctx.lineWidth = 0.014;
    ctx.stroke();
    ctx.fillStyle = "#7b3fa8";
    ell(ctx, -0.17, -0.55, 0.12, 0.09);
    ctx.fill();
    ell(ctx, 0.17, -0.55, 0.12, 0.09);
    ctx.fill();
    ell(ctx, -0.2, -0.04, 0.17, 0.08);
    ctx.fill();
    ell(ctx, 0.2, -0.04, 0.17, 0.08);
    ctx.fill();
    // torso
    ctx.fillStyle = "#f2eef8";
    rr(ctx, -0.4, -1.72, 0.8, 0.8, 0.22);
    ctx.fill();
    ctx.strokeStyle = "rgba(60,30,90,0.55)";
    ctx.stroke();
    ctx.fillStyle = "#8a4cc0";
    rr(ctx, -0.25, -1.62, 0.5, 0.5, 0.15);
    ctx.fill();
    ctx.fillStyle = "#b07ae0";
    rr(ctx, -0.12, -1.55, 0.24, 0.3, 0.1);
    ctx.fill();
    // arms
    ctx.strokeStyle = "#f2eef8";
    ctx.lineWidth = 0.16;
    ctx.beginPath();
    ctx.moveTo(-0.45, -1.6);
    ctx.lineTo(-0.58, -1.2);
    ctx.lineTo(-0.5, -0.9);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0.45, -1.6);
    ctx.lineTo(0.7, -1.75);
    ctx.lineTo(0.62, -2.05);
    ctx.stroke();
    // shoulders
    ctx.fillStyle = "#8a4cc0";
    ell(ctx, -0.47, -1.62, 0.2, 0.17);
    ctx.fill();
    ell(ctx, 0.47, -1.62, 0.2, 0.17);
    ctx.fill();
    // death-beam fingertip
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const pulse = 0.6 + Math.sin(t * 12) * 0.25;
    const fg = ctx.createRadialGradient(0.62, -2.12, 0, 0.62, -2.12, 0.28);
    fg.addColorStop(0, `rgba(255,200,255,${pulse})`);
    fg.addColorStop(0.4, `rgba(220,60,255,${pulse * 0.7})`);
    fg.addColorStop(1, "rgba(220,60,255,0)");
    ctx.fillStyle = fg;
    ctx.fillRect(0.2, -2.55, 0.9, 0.9);
    ctx.restore();
    // head
    ctx.fillStyle = "#f2eef8";
    ell(ctx, 0, -2.0, 0.27, 0.29);
    ctx.fill();
    ctx.strokeStyle = "rgba(60,30,90,0.6)";
    ctx.stroke();
    ctx.fillStyle = "#8a4cc0";
    ctx.beginPath();
    ctx.ellipse(0, -2.03, 0.27, 0.27, 0, Math.PI * 1.03, Math.PI * 1.97);
    ctx.closePath();
    ctx.fill();
    // horns
    ctx.fillStyle = "#f6f2fb";
    for (const sd of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(sd * 0.14, -2.22);
      ctx.quadraticCurveTo(sd * 0.28, -2.35, sd * 0.3, -2.58);
      ctx.quadraticCurveTo(sd * 0.3, -2.35, sd * 0.24, -2.18);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
    // face
    for (const sd of [-1, 1]) {
      ctx.fillStyle = "#d3263a";
      ell(ctx, sd * 0.1, -1.97, 0.065, 0.045);
      ctx.fill();
      ctx.fillStyle = "#111";
      ell(ctx, sd * 0.1, -1.97, 0.02, 0.035);
      ctx.fill();
      ctx.strokeStyle = "#2a1038";
      ctx.lineWidth = 0.03;
      ctx.beginPath();
      ctx.moveTo(sd * 0.19, -2.06);
      ctx.lineTo(sd * 0.03, -2.0);
      ctx.stroke();
    }
    ctx.strokeStyle = "#2a1038";
    ctx.lineWidth = 0.02;
    ctx.beginPath();
    ctx.moveTo(-0.08, -1.82);
    ctx.quadraticCurveTo(0, -1.78, 0.1, -1.85);
    ctx.stroke();
  } else {
    // Cell Jr.
    const wob = Math.sin(t * 8) * 0.03;
    ctx.translate(0, -Math.abs(wob));
    ctx.fillStyle = "#101a2a";
    ell(ctx, -0.2, -0.04, 0.17, 0.06);
    ctx.fill();
    ell(ctx, 0.2, -0.04, 0.17, 0.06);
    ctx.fill();
    ctx.fillStyle = "#3f78b8";
    rr(ctx, -0.3, -0.42, 0.24, 0.4, 0.08);
    ctx.fill();
    rr(ctx, 0.06, -0.42, 0.24, 0.4, 0.08);
    ctx.fill();
    ctx.fillStyle = "#4a88cc";
    ell(ctx, 0, -0.85, 0.42, 0.5);
    ctx.fill();
    ctx.strokeStyle = "rgba(5,15,35,0.75)";
    ctx.lineWidth = 0.02;
    ctx.stroke();
    ctx.fillStyle = "#0e1624";
    for (const [px, py, pr] of [[-0.2, -0.95, 0.06], [0.15, -0.75, 0.07], [-0.1, -0.6, 0.05], [0.28, -1.0, 0.045], [-0.3, -0.72, 0.045], [0.02, -1.1, 0.04]]) {
      ell(ctx, px, py, pr, pr);
      ctx.fill();
    }
    // arms
    ctx.strokeStyle = "#4a88cc";
    ctx.lineWidth = 0.15;
    for (const sd of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(sd * 0.38, -1.0);
      ctx.lineTo(sd * 0.62, -0.85 + wob * sd);
      ctx.lineTo(sd * 0.5, -0.6);
      ctx.stroke();
      ctx.fillStyle = "#0e1624";
      ell(ctx, sd * 0.5, -0.57, 0.08, 0.08);
      ctx.fill();
    }
    // head
    ctx.fillStyle = "#5a9ad8";
    ell(ctx, 0, -1.42, 0.36, 0.3);
    ctx.fill();
    ctx.strokeStyle = "rgba(5,15,35,0.75)";
    ctx.stroke();
    ctx.fillStyle = "#e7e0cc";
    ctx.beginPath();
    ctx.ellipse(0, -1.36, 0.25, 0.2, 0, 0.1, Math.PI - 0.1);
    ctx.fill();
    ctx.fillStyle = "#3f78b8";
    for (const sd of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(sd * 0.12, -1.66);
      ctx.lineTo(sd * 0.2, -1.84);
      ctx.lineTo(sd * 0.28, -1.62);
      ctx.fill();
    }
    for (const sd of [-1, 1]) {
      ctx.fillStyle = "#fff";
      ell(ctx, sd * 0.13, -1.47, 0.08, 0.075);
      ctx.fill();
      ctx.fillStyle = "#c01818";
      ell(ctx, sd * 0.12, -1.46, 0.04, 0.05);
      ctx.fill();
      ctx.fillStyle = "#000";
      ell(ctx, sd * 0.12, -1.46, 0.016, 0.03);
      ctx.fill();
      ctx.strokeStyle = "#0e1624";
      ctx.lineWidth = 0.035;
      ctx.beginPath();
      ctx.moveTo(sd * 0.23, -1.58);
      ctx.lineTo(sd * 0.05, -1.5);
      ctx.stroke();
    }
    ctx.fillStyle = "#3a0d16";
    ell(ctx, 0, -1.27, 0.13, 0.055);
    ctx.fill();
    ctx.fillStyle = "#fff";
    for (let k = -2; k <= 2; k++) ctx.fillRect(k * 0.04 - 0.015, -1.31, 0.03, 0.035);
  }
  ctx.restore();
}

export function drawBeam(ctx: CanvasRenderingContext2D, cx: number, footY: number, s: number, t: number, half: number) {
  ctx.save();
  ctx.translate(cx, footY);
  ctx.scale(s, s);
  ctx.globalCompositeOperation = "lighter";
  ctx.lineCap = "round";
  const y = -1.22 + Math.sin(t * 20) * 0.015;
  const widths = [0.7, 0.46, 0.22, 0.08];
  const cols = ["rgba(150,40,255,0.28)", "rgba(220,70,255,0.45)", "rgba(255,150,255,0.7)", "rgba(255,255,255,0.95)"];
  widths.forEach((w, i) => {
    ctx.strokeStyle = cols[i];
    ctx.lineWidth = w + Math.sin(t * 25 + i) * 0.02;
    ctx.beginPath();
    ctx.moveTo(-half, y);
    ctx.lineTo(half, y);
    ctx.stroke();
  });
  // crackling sparks
  ctx.strokeStyle = "rgba(255,230,255,0.9)";
  ctx.lineWidth = 0.02;
  const seed = Math.floor(t * 16);
  for (let k = 0; k < 3; k++) {
    const r = (a: number) => {
      const q = Math.sin((seed + k * 7) * 12.9898 + a * 78.233) * 43758.5453;
      return q - Math.floor(q);
    };
    const x = (r(1) - 0.5) * 2 * half;
    ctx.beginPath();
    ctx.moveTo(x, y - 0.3);
    ctx.lineTo(x + (r(2) - 0.5) * 0.3, y);
    ctx.lineTo(x + (r(3) - 0.5) * 0.3, y + 0.3);
    ctx.stroke();
  }
  ctx.restore();
}

/* ------------------------------------------------------------------ pickups */

export function drawCoin(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, t: number) {
  const sq = Math.abs(Math.cos(t * 4)) * 0.85 + 0.15;
  ctx.save();
  ctx.translate(cx, cy);
  const g = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
  g.addColorStop(0, "#fff3a6");
  g.addColorStop(1, "#f0a800");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(0, 0, r * sq, r, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#9a5d00";
  ctx.lineWidth = Math.max(1, r * 0.12);
  ctx.stroke();
  if (sq > 0.45) {
    ctx.strokeStyle = "#a86500";
    ctx.lineWidth = Math.max(1, r * 0.17);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(-r * 0.4 * sq, -r * 0.4);
    ctx.lineTo(r * 0.4 * sq, -r * 0.4);
    ctx.lineTo(-r * 0.4 * sq, r * 0.4);
    ctx.lineTo(r * 0.4 * sq, r * 0.4);
    ctx.stroke();
  }
  ctx.restore();
}

export function drawDragonBall(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, n: number, t: number) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.globalCompositeOperation = "lighter";
  const glow = ctx.createRadialGradient(0, 0, r * 0.5, 0, 0, r * 2.4);
  const p = 0.35 + Math.sin(t * 5) * 0.12;
  glow.addColorStop(0, `rgba(255,170,40,${p})`);
  glow.addColorStop(1, "rgba(255,170,40,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(-r * 2.5, -r * 2.5, r * 5, r * 5);
  ctx.globalCompositeOperation = "source-over";
  const g = ctx.createRadialGradient(-r * 0.35, -r * 0.4, r * 0.1, 0, 0, r);
  g.addColorStop(0, "#fff0a0");
  g.addColorStop(0.35, "#ffb52e");
  g.addColorStop(1, "#e2630c");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#a63c00";
  ctx.lineWidth = Math.max(1, r * 0.08);
  ctx.stroke();
  ctx.fillStyle = "#d4161c";
  const sr = r * (n > 4 ? 0.2 : 0.26);
  if (n === 1) {
    star(ctx, 0, 0, sr * 1.4);
    ctx.fill();
  } else {
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 - Math.PI / 2 + t * 0.0;
      star(ctx, Math.cos(a) * r * 0.5, Math.sin(a) * r * 0.5, sr);
      ctx.fill();
    }
  }
  ctx.fillStyle = "rgba(255,255,255,0.65)";
  ctx.beginPath();
  ctx.ellipse(-r * 0.4, -r * 0.5, r * 0.18, r * 0.1, -0.7, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function drawSenzu(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, t: number) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.globalCompositeOperation = "lighter";
  const glow = ctx.createRadialGradient(0, 0, r * 0.3, 0, 0, r * 2.2);
  glow.addColorStop(0, "rgba(140,255,120,0.55)");
  glow.addColorStop(1, "rgba(140,255,120,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(-r * 2.4, -r * 2.4, r * 4.8, r * 4.8);
  ctx.globalCompositeOperation = "source-over";
  ctx.rotate(Math.sin(t * 3) * 0.3 - 0.5);
  const g = ctx.createLinearGradient(0, -r, 0, r);
  g.addColorStop(0, "#c4f58a");
  g.addColorStop(1, "#4aa82a");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(0, 0, r * 0.7, r * 1.05, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#2c6b18";
  ctx.lineWidth = Math.max(1, r * 0.1);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(0, -r * 0.9);
  ctx.quadraticCurveTo(r * 0.25, 0, 0, r * 0.9);
  ctx.stroke();
  ctx.restore();
}
