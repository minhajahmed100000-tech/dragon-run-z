import {
  CHARACTERS,
  CharacterDef,
  drawBeam,
  drawCoin,
  drawDragonBall,
  drawEnemy,
  drawFighter,
  drawSenzu,
  EnemyKind,
  Pose,
} from "./sprites";

/* ------------------------------------------------------------------ config */
const LANE_W = 2.2;
const ROAD_HALF = 3.5;
const CAM_D = 5.5; // camera distance behind the player
const FAR = 92;
const GRAVITY = 28;
const JUMP_V = 10.6;
const SLIDE_TIME = 0.7;
const ZONE_LEN = 900;

/* ----------------------------------------------------------------- palettes */
type RGB = number[];
const hex = (h: string): RGB => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const css = (c: RGB, a = 1) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
const mix = (a: RGB, b: RGB, t: number): RGB => a.map((v, i) => v + (b[i] - v) * t);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const hash = (n: number) => {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
};

interface Pal {
  skyTop: RGB;
  skyBot: RGB;
  fog: RGB;
  roadA: RGB;
  roadB: RGB;
  edge: RGB;
  side: RGB;
  rock: RGB;
  rockL: RGB;
  abyss: RGB;
  sun: RGB;
  leaf: RGB;
  extra: RGB; // [stars, trees, 0]
}

const mk = (o: Record<keyof Pal, string | number[]>): Pal => {
  const out = {} as Pal;
  (Object.keys(o) as (keyof Pal)[]).forEach((k) => {
    const v = o[k];
    out[k] = typeof v === "string" ? hex(v) : v;
  });
  return out;
};

const ZONES: { name: string; pal: Pal }[] = [
  {
    name: "SNAKE WAY",
    pal: mk({
      skyTop: "#2468d0", skyBot: "#a8d8ff", fog: "#cdeaff", roadA: "#e0a640", roadB: "#cf9333",
      edge: "#7b4b18", side: "#55330f", rock: "#7d8cab", rockL: "#b4c1da", abyss: "#7fb4f0",
      sun: "#fff5c4", leaf: "#6fb35a", extra: [0, 0, 0],
    }),
  },
  {
    name: "PLANET NAMEK",
    pal: mk({
      skyTop: "#14946e", skyBot: "#c2f5a8", fog: "#d6f9bb", roadA: "#3fc08c", roadB: "#34ac7b",
      edge: "#1c6b52", side: "#124c3a", rock: "#3e9c88", rockL: "#7ad3b6", abyss: "#58cf9e",
      sun: "#fffbb0", leaf: "#2fb35e", extra: [0, 1, 0],
    }),
  },
  {
    name: "WASTELAND SUNSET",
    pal: mk({
      skyTop: "#5a1c66", skyBot: "#ff9d52", fog: "#ffc690", roadA: "#c26d42", roadB: "#ae5e38",
      edge: "#6b3322", side: "#45200f", rock: "#8c4b3a", rockL: "#d3835e", abyss: "#e57a4a",
      sun: "#ffe69a", leaf: "#a05a3a", extra: [0, 0, 0],
    }),
  },
  {
    name: "OTHER WORLD",
    pal: mk({
      skyTop: "#070420", skyBot: "#5a30a0", fog: "#7a48c8", roadA: "#6a5cc0", roadB: "#5a4cae",
      edge: "#2f2670", side: "#1d1650", rock: "#2e2260", rockL: "#5a47b0", abyss: "#3a2278",
      sun: "#d8f0ff", leaf: "#7a5ad0", extra: [1, 0, 0],
    }),
  },
];

/* ------------------------------------------------------------------- types */
type ObjKind = EnemyKind | "beam" | "coin" | "dball" | "senzu";

interface Obj {
  kind: ObjKind;
  x: number;
  y: number;
  z: number;
  n: number;
  ph: number;
  dead: boolean;
  smashed: boolean;
}

interface Gap {
  z0: number;
  z1: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  glow: boolean;
}

export interface Hud {
  score: number;
  distance: number;
  coins: number;
  balls: number;
  shield: number;
  ss: number; // 0..1 remaining power-up
  zone: string;
}

export interface Result {
  score: number;
  distance: number;
  coins: number;
  fell: boolean;
}

interface Callbacks {
  onHud: (h: Hud) => void;
  onOver: (r: Result) => void;
}

type Mode = "idle" | "play" | "over";

/* ------------------------------------------------------------------ engine */
export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: Callbacks;
  private W = 800;
  private H = 600;
  private dpr = 1;
  private raf = 0;
  private last = 0;
  private time = 0;
  private ro: ResizeObserver;

  mode: Mode = "idle";
  paused = false;
  muted = false;
  private char: CharacterDef = CHARACTERS[0];

  // world state
  private distance = 0;
  private speed = 0;
  private objs: Obj[] = [];
  private gaps: Gap[] = [];
  private nextSpawn = 0;
  private spawnedBalls = 0;
  private particles: Particle[] = [];

  // player
  private px = 0;
  private lane = 0;
  private y = 0;
  private vy = 0;
  private jumpsLeft = 1;
  private slideT = 0;
  private camX = 0;
  private fell = false;
  private deadT = 0;
  private invuln = 0;
  private coyote = 0;
  private gapSafe = 0;
  private shake = 0;
  private flash = 0;

  // progress
  private coins = 0;
  private bonus = 0;
  private balls = 0;
  private shield = 0;
  private ssT = 0;
  private ssMax = 10;
  private zoneIdx = 0;
  private banner: { text: string; sub: string; t: number; dur: number; color: string } | null = null;
  private hudTimer = 0;
  private overFired = false;

  // audio
  private ac: AudioContext | null = null;

  // input
  private touch: { x: number; y: number; id: number } | null = null;
  private onKey = (e: KeyboardEvent) => this.handleKey(e);
  private onDown = (e: PointerEvent) => {
    this.touch = { x: e.clientX, y: e.clientY, id: e.pointerId };
  };
  private onMove = (e: PointerEvent) => {
    if (!this.touch || this.touch.id !== e.pointerId) return;
    const dx = e.clientX - this.touch.x;
    const dy = e.clientY - this.touch.y;
    if (Math.abs(dx) > 28 || Math.abs(dy) > 28) {
      if (Math.abs(dx) > Math.abs(dy)) dx > 0 ? this.right() : this.left();
      else dy < 0 ? this.jump() : this.slide();
      this.touch = { x: e.clientX, y: e.clientY, id: e.pointerId };
    }
  };
  private onUp = () => {
    this.touch = null;
  };

  constructor(canvas: HTMLCanvasElement, cb: Callbacks) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
    this.cb = cb;
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(canvas);
    window.addEventListener("resize", this.onWindowResize);
    window.visualViewport?.addEventListener("resize", this.onWindowResize);
    this.resize();
    window.addEventListener("keydown", this.onKey);
    canvas.addEventListener("pointerdown", this.onDown);
    canvas.addEventListener("pointermove", this.onMove);
    window.addEventListener("pointerup", this.onUp);
    window.addEventListener("pointercancel", this.onUp);
    this.last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.033, (now - this.last) / 1000);
      this.last = now;
      if (!this.paused) {
        this.time += dt;
        this.update(dt);
      }
      this.render();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    window.removeEventListener("resize", this.onWindowResize);
    window.visualViewport?.removeEventListener("resize", this.onWindowResize);
    window.removeEventListener("keydown", this.onKey);
    this.canvas.removeEventListener("pointerdown", this.onDown);
    this.canvas.removeEventListener("pointermove", this.onMove);
    window.removeEventListener("pointerup", this.onUp);
    window.removeEventListener("pointercancel", this.onUp);
    this.ac?.close();
  }

  private onWindowResize = () => this.resize();

  private resize() {
    const r = this.canvas.getBoundingClientRect();
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    // Some Android WebViews report a zero canvas rect during first layout.
    // Fall back to the current viewport so the game scene is still rendered.
    this.W = Math.max(200, r.width || window.innerWidth || 360);
    this.H = Math.max(200, r.height || window.innerHeight || 640);
    this.canvas.width = Math.floor(this.W * this.dpr);
    this.canvas.height = Math.floor(this.H * this.dpr);
    this.canvas.style.width = "100%";
    this.canvas.style.height = "100%";
  }

  /* ------------------------------------------------------------- public api */
  start(c: CharacterDef) {
    this.initAudio();
    this.char = c;
    this.mode = "play";
    this.paused = false;
    this.distance = 0;
    this.speed = 15;
    this.objs = [];
    this.gaps = [];
    this.particles = [];
    this.px = 0;
    this.lane = 0;
    this.y = 0;
    this.vy = 0;
    this.jumpsLeft = c.doubleJump ? 2 : 1;
    this.slideT = 0;
    this.fell = false;
    this.deadT = 0;
    this.invuln = 0;
    this.coyote = 0;
    this.gapSafe = 0;
    this.shake = 0;
    this.flash = 0;
    this.coins = 0;
    this.bonus = 0;
    this.balls = 0;
    this.shield = c.startShield;
    this.ssT = 0;
    this.zoneIdx = 0;
    this.spawnedBalls = 0;
    this.overFired = false;
    this.nextSpawn = 40;
    this.banner = { text: "GO!", sub: "SNAKE WAY", t: 0, dur: 1.8, color: "#ffd23a" };
    this.spawnAhead();
    this.pushHud(true);
  }

  toMenu() {
    this.mode = "idle";
    this.paused = false;
    this.objs = [];
    this.gaps = [];
    this.particles = [];
    this.banner = null;
    this.ssT = 0;
  }

  setPaused(p: boolean) {
    if (this.mode !== "play") return;
    this.paused = p;
  }

  setMuted(m: boolean) {
    this.muted = m;
  }

  /* ------------------------------------------------------------------ input */
  private handleKey(e: KeyboardEvent) {
    const k = e.key;
    if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", " "].includes(k)) e.preventDefault();
    (document.activeElement as HTMLElement | null)?.blur?.();
    if (this.mode !== "play" || this.paused) return;
    if (k === "ArrowLeft" || k === "a" || k === "A") this.left();
    else if (k === "ArrowRight" || k === "d" || k === "D") this.right();
    else if (k === "ArrowUp" || k === "w" || k === "W" || k === " ") this.jump();
    else if (k === "ArrowDown" || k === "s" || k === "S") this.slide();
  }

  left() {
    if (this.mode !== "play" || this.paused) return;
    if (this.lane > -1) {
      this.lane--;
      this.tone(420, 0.06, "triangle", 0.05, 560);
    }
  }
  right() {
    if (this.mode !== "play" || this.paused) return;
    if (this.lane < 1) {
      this.lane++;
      this.tone(420, 0.06, "triangle", 0.05, 560);
    }
  }
  jump() {
    if (this.mode !== "play" || this.paused) return;
    const grounded = this.y <= 0.001;
    if (grounded) {
      this.vy = JUMP_V;
      this.slideT = 0;
      this.jumpsLeft = this.char.doubleJump ? 1 : 0;
      this.tone(300, 0.18, "sine", 0.07, 720);
      this.dust(6);
    } else if (this.jumpsLeft > 0) {
      this.jumpsLeft--;
      this.vy = JUMP_V * 0.95;
      this.tone(500, 0.2, "sine", 0.07, 980);
      this.ring();
    }
  }
  slide() {
    if (this.mode !== "play" || this.paused) return;
    if (this.y <= 0.001) {
      this.slideT = SLIDE_TIME;
      this.tone(260, 0.2, "sawtooth", 0.035, 110);
      this.dust(5);
    } else {
      this.vy = -22;
    }
  }

  /* ------------------------------------------------------------------ audio */
  private initAudio() {
    if (!this.ac) {
      try {
        const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.ac = new Ctor();
      } catch {
        this.ac = null;
      }
    }
    this.ac?.resume?.();
  }

  private tone(f: number, dur: number, type: OscillatorType = "square", vol = 0.05, to?: number, delay = 0) {
    if (this.muted || !this.ac) return;
    const ac = this.ac;
    const t0 = ac.currentTime + delay;
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t0);
    if (to) o.frequency.exponentialRampToValueAtTime(to, t0 + dur);
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(ac.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }

  private noise(dur: number, vol = 0.12) {
    if (this.muted || !this.ac) return;
    const ac = this.ac;
    const len = Math.floor(ac.sampleRate * dur);
    const buf = ac.createBuffer(1, len, ac.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = ac.createBufferSource();
    src.buffer = buf;
    const g = ac.createGain();
    g.gain.value = vol;
    src.connect(g).connect(ac.destination);
    src.start();
  }

  /* ------------------------------------------------------------- game logic */
  private get scoreMult() {
    return this.char.scoreMult;
  }
  private get score() {
    return Math.floor((this.distance * 0.5 + this.bonus) * this.scoreMult);
  }
  private get ssOn() {
    return this.ssT > 0;
  }

  private inGap(z: number) {
    for (const g of this.gaps) if (z > g.z0 + 0.25 && z < g.z1 - 0.25) return true;
    return false;
  }

  private pushObj(kind: ObjKind, x: number, z: number, y = 0, n = 0) {
    this.objs.push({ kind, x, y, z, n, ph: Math.random() * 6, dead: false, smashed: false });
  }

  private coinLine(lane: number, z: number, n: number, y = 0.9) {
    for (let i = 0; i < n; i++) this.pushObj("coin", lane * LANE_W, z + i * 1.7, y);
  }

  private arcCoins(lane: number, z: number, n: number, len: number, peak: number) {
    for (let i = 0; i < n; i++) {
      const u = n > 1 ? i / (n - 1) : 0;
      this.pushObj("coin", lane * LANE_W, z + u * len, 0.9 + Math.sin(Math.PI * u) * peak);
    }
  }

  private shuffledLanes() {
    const l = [-1, 0, 1];
    for (let i = 2; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [l[i], l[j]] = [l[j], l[i]];
    }
    return l;
  }

  private spawnAhead() {
    while (this.nextSpawn < this.distance + FAR + 12) this.spawnPattern();
  }

  private spawnPattern() {
    const z = this.nextSpawn;
    const diff = Math.min(1, this.distance / 4500);
    const r = Math.random();
    const L = this.shuffledLanes();
    let len = 4;
    const first = this.distance < 30 && z < 80;

    if (first || r < 0.2) {
      const n = 6 + Math.floor(Math.random() * 5);
      this.coinLine(L[0], z, n);
      len = n * 1.7;
    } else if (r < 0.4) {
      // saibamen ambush - jump over them
      let c = 1;
      if (Math.random() < 0.35 + 0.4 * diff) c++;
      if (Math.random() < 0.15 + 0.35 * diff) c++;
      for (let i = 0; i < c; i++) this.pushObj("saibaman", L[i] * LANE_W, z);
      this.arcCoins(L[0], z - 3, 6, 6, 1.0);
      len = 4;
    } else if (r < 0.6) {
      // tall fighters - switch lanes
      const c = Math.random() < 0.3 + 0.45 * diff ? 2 : 1;
      for (let i = 0; i < c; i++) this.pushObj(Math.random() < 0.5 ? "frieza" : "celljr", L[i] * LANE_W, z);
      this.coinLine(L[2], z - 4, 7);
      len = 5;
    } else if (r < 0.74) {
      // death beams - slide under them
      const c = 1 + Math.floor(Math.random() * (diff > 0.25 ? 3 : 2));
      for (let i = 0; i < c; i++) {
        this.pushObj("beam", L[i] * LANE_W, z);
        this.coinLine(L[i], z - 1.5, 3, 0.45);
      }
      len = 4;
    } else if (r < 0.88) {
      // gap in the road - jump across
      const gl = 2 * Math.ceil((5 + this.speed * 0.1) / 2);
      const gz = Math.ceil(z / 2) * 2;
      this.gaps.push({ z0: gz, z1: gz + gl });
      this.arcCoins(L[0], gz - 1, 8, gl + 2, 1.0);
      len = gl + 3 + (gz - z);
    } else {
      // mixed
      this.pushObj(Math.random() < 0.5 ? "frieza" : "celljr", L[0] * LANE_W, z);
      this.pushObj("saibaman", L[1] * LANE_W, z);
      this.coinLine(L[2], z - 3, 8);
      len = 5;
    }

    const rest = Math.max(10, this.speed * (0.95 - 0.28 * diff)) + Math.random() * 5;
    // bonus pickups in the safe breathing room
    const bz = z + len + rest * 0.5;
    const br = Math.random();
    if (!first) {
      if (br < 0.2) {
        this.pushObj("dball", L[Math.floor(Math.random() * 3)] * LANE_W, bz, 0.95, (this.spawnedBalls++ % 7) + 1);
      } else if (br < 0.28) {
        this.pushObj("senzu", L[Math.floor(Math.random() * 3)] * LANE_W, bz, 0.95);
      }
    }
    this.nextSpawn = z + len + rest;
  }

  private update(dt: number) {
    // particles
    for (const p of this.particles) {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 260 * dt;
      p.life -= dt;
    }
    this.particles = this.particles.filter((p) => p.life > 0);
    this.shake = Math.max(0, this.shake - dt * 2.2);
    this.flash = Math.max(0, this.flash - dt * 1.8);
    if (this.banner) {
      this.banner.t += dt;
      if (this.banner.t > this.banner.dur) this.banner = null;
    }

    if (this.mode === "idle") {
      this.distance += 9 * dt;
      this.camX += (0 - this.camX) * Math.min(1, dt * 3);
      return;
    }

    if (this.mode === "over") {
      this.deadT += dt;
      if (this.fell) {
        this.vy -= GRAVITY * dt;
        this.y += this.vy * dt;
      }
      this.speed *= Math.max(0, 1 - dt * 6);
      this.distance += this.speed * dt;
      if (this.deadT > 1.1 && !this.overFired) {
        this.overFired = true;
        this.cb.onOver({ score: this.score, distance: Math.floor(this.distance), coins: this.coins, fell: this.fell });
      }
      return;
    }

    const c = this.char;
    // speed
    const base = Math.min(31, 15 + this.distance * 0.0042);
    const target = this.ssOn ? base * 1.25 : base;
    this.speed += (target - this.speed) * Math.min(1, dt * 2);
    this.distance += this.speed * dt;

    // power up timer
    if (this.ssT > 0) {
      this.ssT -= dt;
      if (this.ssT <= 0) {
        this.ssT = 0;
        this.banner = { text: "POWER DOWN", sub: "Collect 7 Dragon Balls to power up again", t: 0, dur: 1.8, color: "#9ad0ff" };
        this.invuln = 1;
        this.gapSafe = 0.7;
      }
    }
    this.invuln = Math.max(0, this.invuln - dt);
    this.slideT = Math.max(0, this.slideT - dt);

    // lateral
    const tx = this.lane * LANE_W;
    this.px += (tx - this.px) * Math.min(1, dt * 14);
    this.camX += (this.px * 0.6 - this.camX) * Math.min(1, dt * 5);

    // vertical
    this.vy -= GRAVITY * dt;
    this.y += this.vy * dt;
    this.gapSafe = Math.max(0, this.gapSafe - dt);
    if (this.y <= 0) {
      if (!this.ssOn && this.gapSafe <= 0 && this.inGap(this.distance)) {
        this.coyote += dt;
        if (this.coyote > 0.1) {
          this.die(true);
          return;
        }
      } else {
        this.coyote = 0;
      }
      this.y = 0;
      this.vy = 0;
      this.jumpsLeft = c.doubleJump ? 1 : 0;
    }

    // zones
    const zi = Math.floor(this.distance / ZONE_LEN) % ZONES.length;
    if (zi !== this.zoneIdx) {
      this.zoneIdx = zi;
      this.banner = { text: ZONES[zi].name, sub: `${Math.floor(this.distance)} m`, t: 0, dur: 2.2, color: "#fff" };
    }

    this.spawnAhead();

    // collisions & pickups
    const ph = this.slideT > 0 ? 0.75 : 1.7;
    const flying = this.ssOn;
    const magnet = c.magnet || flying;
    for (const o of this.objs) {
      if (o.dead) continue;
      const dz = o.z - this.distance;
      if (magnet && (o.kind === "coin") && dz > -1 && dz < 10 && Math.abs(o.x - this.px) < 4.2) {
        o.x += (this.px - o.x) * Math.min(1, dt * 9);
        o.y += (this.y + 0.9 - o.y) * Math.min(1, dt * 9);
        o.z -= (flying ? 6 : 3) * dt;
      }
      if (Math.abs(dz) > 0.85) continue;
      const dx = Math.abs(o.x - this.px);
      if (o.kind === "coin") {
        if (dx < 1.0 && o.y > this.y - 0.4 && o.y < this.y + ph + 0.3) this.collectCoin(o);
      } else if (o.kind === "dball") {
        if (dx < 1.1 && o.y > this.y - 0.5 && o.y < this.y + ph + 0.4) this.collectBall(o);
      } else if (o.kind === "senzu") {
        if (dx < 1.1 && o.y > this.y - 0.5 && o.y < this.y + ph + 0.4) {
          o.dead = true;
          this.shield = Math.min(2, this.shield + 1);
          this.tone(600, 0.1, "triangle", 0.07, 1200);
          this.tone(900, 0.2, "triangle", 0.07, 1600, 0.08);
          this.sparkle(o, "150,255,130");
          this.banner = { text: "SENZU BEAN!", sub: "Shield restored", t: 0, dur: 1.2, color: "#9dff7a" };
        }
      } else {
        // hazards
        let bottom = 0;
        let top = 2.6;
        let half = 0.55;
        if (o.kind === "saibaman") {
          top = 0.95;
          half = 0.5;
        } else if (o.kind === "celljr") {
          top = 2.0;
          half = 0.75;
        } else if (o.kind === "frieza") {
          top = 2.5;
          half = 0.65;
        } else if (o.kind === "beam") {
          bottom = 0.95;
          top = 1.9;
          half = 1.1;
        }
        const overlapY = this.y < top && this.y + ph > bottom;
        if (dx < half + 0.28 && overlapY) this.hit(o);
        if (this.mode !== "play") return;
      }
    }
    this.objs = this.objs.filter((o) => !o.dead && o.z > this.distance - 8);
    this.gaps = this.gaps.filter((g) => g.z1 > this.distance - 8);

    // running dust
    if (this.y <= 0 && Math.random() < dt * 14) this.dust(1);

    this.hudTimer -= dt;
    if (this.hudTimer <= 0) this.pushHud();
  }

  private collectCoin(o: Obj) {
    o.dead = true;
    this.coins++;
    this.bonus += 10;
    this.sparkle(o, "255,220,60", 5);
    this.tone(1000 + (this.coins % 8) * 60, 0.09, "square", 0.035, 1500);
  }

  private collectBall(o: Obj) {
    o.dead = true;
    this.balls++;
    this.bonus += 100;
    this.sparkle(o, "255,170,40", 14);
    this.tone(700, 0.12, "triangle", 0.08, 1400);
    this.tone(1100, 0.18, "triangle", 0.08, 1800, 0.1);
    if (this.balls >= 7) {
      this.balls = 0;
      this.ssMax = this.char.ssTime;
      this.ssT = this.ssMax;
      this.flash = 1;
      this.shake = 1;
      this.bonus += 500;
      this.banner = {
        text: this.char.formName + "!",
        sub: "THE DRAGON GRANTS YOUR WISH — INVINCIBLE!",
        t: 0,
        dur: 2.4,
        color: "#ffe14a",
      };
      for (let i = 0; i < 5; i++) this.tone(300 + i * 140, 0.35, "sawtooth", 0.05, 600 + i * 260, i * 0.07);
      this.noise(0.6, 0.12);
    } else {
      this.banner = { text: `DRAGON BALL ${this.balls}/7`, sub: "", t: 0, dur: 1.0, color: "#ffb02e" };
    }
  }

  private hit(o: Obj) {
    if (this.ssOn) {
      o.dead = true;
      o.smashed = true;
      this.bonus += 50;
      this.explode(o);
      this.shake = Math.max(this.shake, 0.5);
      this.noise(0.25, 0.1);
      return;
    }
    if (this.invuln > 0) return;
    if (this.shield > 0) {
      this.shield--;
      this.invuln = 1.4;
      o.dead = true;
      this.explode(o);
      this.shake = 0.8;
      this.noise(0.3, 0.14);
      this.banner = { text: "SHIELD BROKEN", sub: "", t: 0, dur: 1.0, color: "#ff8a8a" };
      return;
    }
    this.die(false);
  }

  private die(fell: boolean) {
    this.mode = "over";
    this.fell = fell;
    this.deadT = 0;
    this.shake = fell ? 0 : 1;
    this.vy = fell ? -3 : 0;
    if (fell) {
      this.tone(600, 0.9, "sine", 0.08, 80);
    } else {
      this.noise(0.5, 0.2);
      this.tone(220, 0.5, "sawtooth", 0.08, 50);
      this.flash = 0.6;
    }
    this.pushHud(true);
  }

  private pushHud(force = false) {
    this.hudTimer = force ? 0.1 : 0.1;
    this.cb.onHud({
      score: this.score,
      distance: Math.floor(this.distance),
      coins: this.coins,
      balls: this.balls,
      shield: this.shield,
      ss: this.ssOn ? this.ssT / this.ssMax : 0,
      zone: ZONES[this.zoneIdx].name,
    });
  }

  /* -------------------------------------------------------------- particles */
  private projectObj(o: { x: number; y: number; z: number }) {
    return this.proj(o.x, o.y, o.z - this.distance);
  }
  private sparkle(o: Obj, rgb: string, n = 8) {
    const p = this.projectObj(o);
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const v = 60 + Math.random() * 140;
      this.particles.push({ x: p.sx, y: p.sy, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 60, life: 0.5, max: 0.5, size: 2 + Math.random() * 3, color: rgb, glow: true });
    }
  }
  private explode(o: Obj) {
    const p = this.projectObj({ x: o.x, y: 1, z: o.z });
    const cols = ["255,240,160", "255,150,40", "255,90,30", "255,255,255"];
    for (let i = 0; i < 34; i++) {
      const a = Math.random() * Math.PI * 2;
      const v = 80 + Math.random() * 320;
      this.particles.push({
        x: p.sx, y: p.sy, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 120, life: 0.7, max: 0.7,
        size: (4 + Math.random() * 9) * Math.max(0.5, p.s / 60), color: cols[i % 4], glow: true,
      });
    }
  }
  private dust(n: number) {
    const p = this.proj(this.px, 0, 0);
    for (let i = 0; i < n; i++) {
      this.particles.push({
        x: p.sx + (Math.random() - 0.5) * p.s * 0.6, y: p.sy, vx: (Math.random() - 0.5) * 90, vy: -20 - Math.random() * 50,
        life: 0.4, max: 0.4, size: 3 + Math.random() * 4, color: "255,240,210", glow: false,
      });
    }
  }
  private ring() {
    const p = this.proj(this.px, this.y, 0);
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      this.particles.push({ x: p.sx, y: p.sy, vx: Math.cos(a) * 130, vy: Math.sin(a) * 60, life: 0.35, max: 0.35, size: 3, color: this.char.aura, glow: true });
    }
  }

  /* ----------------------------------------------------------------- render */
  private horizon = 0;
  private F = 400;
  private camH = 4;

  private proj(x: number, y: number, z: number) {
    const s = this.F / (z + CAM_D);
    const curve = this.curveAmt() * z * z * 0.0011;
    return { sx: this.W / 2 + (x + (z > 0 ? curve : 0) - this.camX) * s, sy: this.horizon + (this.camH - y) * s, s };
  }

  private curveAmt() {
    const d = this.distance;
    return Math.sin(d * 0.0021) * 1.1 + Math.sin(d * 0.0057 + 1) * 0.5;
  }

  private palette(): Pal {
    const d = this.distance;
    const idx = Math.floor(d / ZONE_LEN);
    const fr = d - idx * ZONE_LEN;
    const a = ZONES[idx % ZONES.length].pal;
    if (fr < ZONE_LEN - 120) return a;
    const t = (fr - (ZONE_LEN - 120)) / 120;
    const b = ZONES[(idx + 1) % ZONES.length].pal;
    const out = {} as Pal;
    (Object.keys(a) as (keyof Pal)[]).forEach((k) => (out[k] = mix(a[k], b[k], t)));
    return out;
  }

  private render() {
    const { ctx, W, H } = this;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const pal = this.palette();
    const t = this.time;
    this.horizon = H * 0.33;
    this.F = Math.min(W * 0.55, H * 0.82);
    this.camH = clamp(((H * 0.8 - this.horizon) * CAM_D) / this.F, 3, 6.4);

    ctx.save();
    if (this.shake > 0) ctx.translate((Math.random() - 0.5) * this.shake * 14, (Math.random() - 0.5) * this.shake * 14);

    this.drawSky(pal, t);
    this.drawRoad(pal);

    // fog band at horizon
    const fb = ctx.createLinearGradient(0, this.horizon - 6, 0, this.horizon + H * 0.13);
    fb.addColorStop(0, css(pal.fog, 0.95));
    fb.addColorStop(1, css(pal.fog, 0));
    ctx.fillStyle = fb;
    ctx.fillRect(0, this.horizon - 6, W, H * 0.13 + 6);

    // collect drawables
    const items: { z: number; draw: () => void }[] = [];
    this.collectScenery(pal, items);
    for (const o of this.objs) {
      const z = o.z - this.distance;
      if (z > FAR || z < -3.5) continue;
      items.push({ z, draw: () => this.drawObj(o, z, t) });
    }
    if (this.mode !== "idle") items.push({ z: 0, draw: () => this.drawPlayer(t) });
    items.sort((a, b) => b.z - a.z);
    for (const it of items) it.draw();

    // particles
    for (const p of this.particles) {
      const a = Math.max(0, p.life / p.max);
      ctx.globalCompositeOperation = p.glow ? "lighter" : "source-over";
      ctx.fillStyle = `rgba(${p.color},${a * (p.glow ? 0.9 : 0.5)})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * (0.4 + a * 0.6), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalCompositeOperation = "source-over";

    // power-up speed lines
    if (this.ssOn && this.mode === "play") {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.strokeStyle = `rgba(${this.char.aura},0.28)`;
      for (let i = 0; i < 22; i++) {
        const a = hash(i * 3.3 + Math.floor(t * 14) * 0.37) * Math.PI * 2;
        const r0 = Math.min(W, H) * (0.3 + hash(i + 9) * 0.25);
        const r1 = r0 + Math.min(W, H) * (0.35 + hash(i + 4) * 0.4);
        ctx.lineWidth = 1 + hash(i + 1) * 3;
        ctx.beginPath();
        ctx.moveTo(W / 2 + Math.cos(a) * r0 * 1.4, H * 0.55 + Math.sin(a) * r0);
        ctx.lineTo(W / 2 + Math.cos(a) * r1 * 1.4, H * 0.55 + Math.sin(a) * r1);
        ctx.stroke();
      }
      ctx.restore();
    }
    ctx.restore();

    if (this.flash > 0) {
      ctx.fillStyle = `rgba(255,${this.mode === "over" ? 80 : 245},${this.mode === "over" ? 60 : 170},${this.flash * 0.75})`;
      ctx.fillRect(0, 0, W, H);
    }

    // vignette
    const vg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.45, W / 2, H / 2, Math.max(W, H) * 0.8);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(0,0,0,0.35)");
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);

    this.drawBanner();
  }

  private drawBanner() {
    const b = this.banner;
    if (!b) return;
    const { ctx, W, H } = this;
    const a = Math.min(1, b.t * 5, (b.dur - b.t) * 3);
    const sc = 1 + Math.max(0, 0.3 - b.t) * 1.5;
    ctx.save();
    ctx.globalAlpha = clamp(a, 0, 1);
    ctx.translate(W / 2, H * 0.2);
    ctx.scale(sc, sc);
    ctx.textAlign = "center";
    const size = Math.min(64, W * 0.11);
    ctx.font = `${size}px Bangers, Impact, sans-serif`;
    ctx.lineJoin = "round";
    ctx.lineWidth = size * 0.16;
    ctx.strokeStyle = "rgba(20,10,40,0.9)";
    ctx.strokeText(b.text, 0, 0);
    ctx.fillStyle = b.color;
    ctx.shadowColor = b.color;
    ctx.shadowBlur = 20;
    ctx.fillText(b.text, 0, 0);
    ctx.shadowBlur = 0;
    if (b.sub) {
      ctx.font = `${Math.max(12, size * 0.32)}px Rajdhani, sans-serif`;
      ctx.fillStyle = "#fff";
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(20,10,40,0.85)";
      ctx.strokeText(b.sub, 0, size * 0.5);
      ctx.fillText(b.sub, 0, size * 0.5);
    }
    ctx.restore();
  }

  private drawSky(pal: Pal, t: number) {
    const { ctx, W, H, horizon } = this;
    const g = ctx.createLinearGradient(0, 0, 0, horizon);
    g.addColorStop(0, css(pal.skyTop));
    g.addColorStop(1, css(pal.skyBot));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, horizon + 1);

    // stars
    if (pal.extra[0] > 0.02) {
      ctx.fillStyle = `rgba(255,255,255,${pal.extra[0] * 0.85})`;
      for (let i = 0; i < 70; i++) {
        const tw = 0.5 + 0.5 * Math.sin(t * 2 + i);
        ctx.globalAlpha = pal.extra[0] * (0.3 + tw * 0.7);
        ctx.fillRect(hash(i) * W, hash(i + 50) * horizon * 0.95, 1 + hash(i + 7) * 1.5, 1 + hash(i + 7) * 1.5);
      }
      ctx.globalAlpha = 1;
    }

    // sun / halo
    const sx = W * 0.72 - this.curveAmt() * 30 - this.camX * 6;
    const sy = horizon * 0.58;
    const sr = Math.min(W, H) * 0.09;
    const sg = ctx.createRadialGradient(sx, sy, sr * 0.3, sx, sy, sr * 4);
    sg.addColorStop(0, css(pal.sun, 0.8));
    sg.addColorStop(1, css(pal.sun, 0));
    ctx.fillStyle = sg;
    ctx.fillRect(sx - sr * 4, sy - sr * 4, sr * 8, sr * 8);
    ctx.fillStyle = css(pal.sun, 1);
    ctx.beginPath();
    ctx.arc(sx, sy, sr, 0, Math.PI * 2);
    ctx.fill();

    // drifting sky clouds
    ctx.fillStyle = css(mix(pal.fog, [255, 255, 255], 0.5), 0.55);
    for (let i = 0; i < 7; i++) {
      const cx = ((hash(i * 4.1) * (W + 300) - this.distance * (0.4 + hash(i) * 0.4) - this.camX * 8) % (W + 300) + (W + 300)) % (W + 300) - 150;
      const cy = horizon * (0.25 + hash(i + 3) * 0.6);
      const cw = 60 + hash(i + 8) * 90;
      for (let k = 0; k < 4; k++) {
        ctx.beginPath();
        ctx.ellipse(cx + (k - 1.5) * cw * 0.3, cy + Math.sin(k * 2) * 4, cw * 0.32, cw * 0.14, 0, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // cloud sea / abyss
    const ag = ctx.createLinearGradient(0, horizon, 0, H);
    ag.addColorStop(0, css(pal.fog));
    ag.addColorStop(0.35, css(mix(pal.fog, pal.abyss, 0.6)));
    ag.addColorStop(1, css(mix(pal.abyss, pal.skyTop, 0.45)));
    ctx.fillStyle = ag;
    ctx.fillRect(0, horizon, W, H - horizon);
  }

  private drawRoad(pal: Pal) {
    const { ctx } = this;
    const T = 1.6; // thickness of the floating road
    const k0 = Math.floor((this.distance - 4) / 2);
    const k1 = Math.ceil((this.distance + FAR) / 2);
    for (let k = k1; k >= k0; k--) {
      const a = Math.max(k * 2 - this.distance, -4.6);
      const b = k * 2 + 2 - this.distance;
      if (b <= -4.5) continue;
      const gapHere = this.inGap(k * 2 + 1);
      if (gapHere) continue;
      const fogT = clamp(Math.pow(Math.max(0, b) / FAR, 1.15), 0, 1);
      const top = mix(k % 2 === 0 ? pal.roadA : pal.roadB, pal.fog, fogT);
      const edge = mix(pal.edge, pal.fog, fogT);
      const side = mix(pal.side, pal.fog, fogT);
      const hw = ROAD_HALF;
      const p1 = this.proj(-hw, 0, a);
      const p2 = this.proj(hw, 0, a);
      const p3 = this.proj(hw, 0, b);
      const p4 = this.proj(-hw, 0, b);
      // near face (visible at gap edges)
      if (this.inGap(k * 2 - 1) || k === k0) {
        const q1 = this.proj(-hw, -T, a);
        const q2 = this.proj(hw, -T, a);
        ctx.fillStyle = css(side);
        ctx.beginPath();
        ctx.moveTo(p1.sx, p1.sy);
        ctx.lineTo(p2.sx, p2.sy);
        ctx.lineTo(q2.sx, q2.sy);
        ctx.lineTo(q1.sx, q1.sy);
        ctx.closePath();
        ctx.fill();
        // brick lines
        ctx.strokeStyle = css(mix(side, [0, 0, 0], 0.35));
        ctx.lineWidth = 1;
        for (let i = 1; i < 4; i++) {
          const u = i / 4;
          ctx.beginPath();
          ctx.moveTo(p1.sx + (q1.sx - p1.sx) * u, p1.sy + (q1.sy - p1.sy) * u);
          ctx.lineTo(p2.sx + (q2.sx - p2.sx) * u, p2.sy + (q2.sy - p2.sy) * u);
          ctx.stroke();
        }
      }
      // top
      ctx.fillStyle = css(top);
      ctx.beginPath();
      ctx.moveTo(p1.sx, p1.sy);
      ctx.lineTo(p2.sx, p2.sy);
      ctx.lineTo(p3.sx, p3.sy);
      ctx.lineTo(p4.sx, p4.sy);
      ctx.closePath();
      ctx.fill();
      // edges
      const ew = 0.35;
      for (const sd of [-1, 1]) {
        const e1 = this.proj(sd * hw, 0, a);
        const e2 = this.proj(sd * (hw - ew), 0, a);
        const e3 = this.proj(sd * (hw - ew), 0, b);
        const e4 = this.proj(sd * hw, 0, b);
        ctx.fillStyle = css(edge);
        ctx.beginPath();
        ctx.moveTo(e1.sx, e1.sy);
        ctx.lineTo(e2.sx, e2.sy);
        ctx.lineTo(e3.sx, e3.sy);
        ctx.lineTo(e4.sx, e4.sy);
        ctx.closePath();
        ctx.fill();
      }
      // lane lines
      ctx.strokeStyle = `rgba(255,255,255,${0.22 * (1 - fogT)})`;
      ctx.lineWidth = Math.max(1, 0.07 * p1.s);
      for (const lx of [-LANE_W / 2, LANE_W / 2]) {
        const l1 = this.proj(lx, 0, a);
        const l2 = this.proj(lx, 0, b - (b - a) * 0.35);
        ctx.beginPath();
        ctx.moveTo(l1.sx, l1.sy);
        ctx.lineTo(l2.sx, l2.sy);
        ctx.stroke();
      }
    }
  }

  private collectScenery(pal: Pal, items: { z: number; draw: () => void }[]) {
    const { ctx, W, H } = this;
    const step = 8;
    const i0 = Math.floor((this.distance - 6) / step);
    for (let i = i0; i * step - this.distance < FAR; i++) {
      const z = i * step - this.distance;
      if (z < -4) continue;
      for (const side of [-1, 1]) {
        const seed = i * 2 + (side > 0 ? 1 : 0);
        if (hash(seed) < 0.4) continue;
        const x = side * (6.5 + hash(seed + 11) * 15);
        const topY = -1 + hash(seed + 5) * 8;
        const w = 1.3 + hash(seed + 3) * 2.4;
        const tree = pal.extra[1] > 0.5 && hash(seed + 21) < 0.65;
        items.push({
          z,
          draw: () => {
            const p = this.proj(x, topY, z);
            const al = clamp(1 - (z - 55) / 40, 0, 1);
            if (al <= 0) return;
            ctx.globalAlpha = al;
            const wp = w * p.s;
            const base = H + 80;
            ctx.fillStyle = css(pal.rock);
            ctx.beginPath();
            ctx.moveTo(p.sx - wp * 0.62, p.sy);
            ctx.lineTo(p.sx + wp * 0.62, p.sy);
            ctx.lineTo(p.sx + wp * 1.3, base);
            ctx.lineTo(p.sx - wp * 1.3, base);
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = css(pal.rockL);
            ctx.beginPath();
            ctx.moveTo(p.sx + wp * 0.05, p.sy);
            ctx.lineTo(p.sx + wp * 0.62, p.sy);
            ctx.lineTo(p.sx + wp * 1.3, base);
            ctx.lineTo(p.sx + wp * 0.2, base);
            ctx.closePath();
            ctx.globalAlpha = al * 0.55;
            ctx.fill();
            ctx.globalAlpha = al;
            // cap
            ctx.fillStyle = css(tree ? pal.leaf : pal.rockL);
            ctx.beginPath();
            ctx.ellipse(p.sx, p.sy, wp * 0.72, wp * 0.2, 0, 0, Math.PI * 2);
            ctx.fill();
            if (tree) {
              ctx.fillStyle = css(mix(pal.rock, [30, 30, 20], 0.4));
              ctx.fillRect(p.sx - wp * 0.05, p.sy - wp * 0.9, wp * 0.1, wp * 0.9);
              ctx.fillStyle = css(mix(pal.leaf, [255, 255, 255], 0.12));
              ctx.beginPath();
              ctx.arc(p.sx, p.sy - wp * 0.95, wp * 0.45, 0, Math.PI * 2);
              ctx.fill();
              ctx.fillStyle = css(mix(pal.leaf, [0, 0, 0], 0.2));
              ctx.beginPath();
              ctx.arc(p.sx + wp * 0.12, p.sy - wp * 0.88, wp * 0.32, 0, Math.PI * 2);
              ctx.fill();
            }
            ctx.globalAlpha = 1;
          },
        });
      }
    }
    // cloud puffs below the road
    const cs = 5;
    const c0 = Math.floor((this.distance - 6) / cs);
    for (let i = c0; i * cs - this.distance < FAR; i++) {
      const z = i * cs - this.distance;
      if (z < -4) continue;
      for (let n = 0; n < 2; n++) {
        const seed = i * 3 + n * 101;
        const x = (hash(seed) - 0.5) * 70;
        const y = -3.5 - hash(seed + 1) * 14;
        const sz = 3 + hash(seed + 2) * 5;
        items.push({
          z: z + 0.01,
          draw: () => {
            const p = this.proj(x, y, z);
            const al = clamp(1 - (z - 40) / 52, 0, 1) * 0.65;
            if (al <= 0) return;
            ctx.fillStyle = css(mix(pal.fog, [255, 255, 255], 0.55), al);
            for (let k = 0; k < 3; k++) {
              ctx.beginPath();
              ctx.ellipse(p.sx + (k - 1) * sz * p.s * 0.5, p.sy - (k === 1 ? sz * p.s * 0.1 : 0), sz * p.s * 0.55, sz * p.s * 0.22, 0, 0, Math.PI * 2);
              ctx.fill();
            }
          },
        });
      }
    }
    void W;
  }

  private drawObj(o: Obj, z: number, t: number) {
    const { ctx } = this;
    const al = clamp(1 - (z - 55) / 36, 0, 1);
    if (al <= 0) return;
    ctx.globalAlpha = al;
    const p = this.projectObj(o);
    const s = p.s;
    const gp = this.proj(o.x, 0, z);
    const shadow = (w: number) => {
      ctx.fillStyle = "rgba(0,0,0,0.28)";
      ctx.beginPath();
      ctx.ellipse(gp.sx, gp.sy, w * s, w * s * 0.28, 0, 0, Math.PI * 2);
      ctx.fill();
    };
    switch (o.kind) {
      case "coin":
        drawCoin(ctx, p.sx, p.sy, 0.36 * s, t + o.ph);
        break;
      case "dball":
        shadow(0.4);
        drawDragonBall(ctx, p.sx, p.sy, 0.46 * s, o.n, t);
        break;
      case "senzu":
        shadow(0.3);
        drawSenzu(ctx, p.sx, p.sy, 0.36 * s, t);
        break;
      case "beam":
        drawBeam(ctx, gp.sx, gp.sy, s, t, LANE_W / 2 + 0.02);
        break;
      case "saibaman":
        shadow(0.5);
        drawEnemy(ctx, "saibaman", gp.sx, gp.sy, s * 1.0, t + o.ph);
        break;
      case "frieza":
        shadow(0.6);
        drawEnemy(ctx, "frieza", gp.sx, gp.sy, s * 1.0, t + o.ph);
        break;
      case "celljr":
        shadow(0.7);
        drawEnemy(ctx, "celljr", gp.sx, gp.sy, s * 1.0, t + o.ph);
        break;
    }
    ctx.globalAlpha = 1;
  }

  private drawPlayer(t: number) {
    const { ctx } = this;
    const p = this.proj(this.px, this.y, 0);
    const gp = this.proj(this.px, 0, 0);
    const s = p.s;
    // ground shadow
    if (!this.fell && !this.inGap(this.distance)) {
      const k = 1 / (1 + this.y * 0.6);
      ctx.fillStyle = `rgba(0,0,0,${0.3 * k})`;
      ctx.beginPath();
      ctx.ellipse(gp.sx, gp.sy, 0.5 * s * k, 0.5 * s * 0.26 * k, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    let pose: Pose = "run";
    if (this.y > 0.02) pose = "jump";
    else if (this.slideT > 0) pose = "slide";
    ctx.save();
    if (this.invuln > 0 && !this.ssOn) ctx.globalAlpha = 0.45 + 0.4 * Math.sin(t * 40);
    if (this.mode === "over") {
      const rot = this.fell ? Math.min(this.deadT * 2, 0.6) : Math.min(this.deadT * 6, 1.4);
      ctx.translate(p.sx, p.sy);
      ctx.rotate(rot * (this.px >= 0 ? -1 : 1) * (this.fell ? 0.4 : 1));
      ctx.translate(-p.sx, -p.sy);
      pose = "jump";
    }
    drawFighter(ctx, this.char, p.sx, p.sy, 1.8 * s, this.mode === "over" ? 0 : t, pose, this.ssOn);
    ctx.restore();
  }
}
