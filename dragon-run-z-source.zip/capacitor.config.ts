import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.dragonrunz.game',
  appName: 'Dragon Run Z',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#09090f',
    allowMixedContent: false
  }
};

export default config;
